<?php namespace App\Filters;
 
use CodeIgniter\HTTP\RequestInterface;
use CodeIgniter\HTTP\ResponseInterface;
use CodeIgniter\Filters\FilterInterface;
 
class Auth implements FilterInterface
{
    public function before(RequestInterface $request, $arguments = null)
    {
	 
	  	$this->session = session();
	  	
	   // echo "<pre>";print_r($this->session);
		
		// if user not logged in
         if(!$this->session->get('logged_in')){
           return redirect()->to(base_url());
        }
		
		$this->checkPageAccess($this->session);
		// if($this->session->has('employee_page') &&  $this->session->get('employee_page') == 1)
    }

	public function checkPageAccess($session){
		
		$router = service('router'); 
	 
		$page_access = 1;
		$controller  = class_basename($router->controllerName());  
		if($controller == "employees"){
			if($session->get('employee_page') ==1){
				$page_access = 0 ;
			}
		}else if($controller == "application"){
		    
			if($session->get('application_page') ==1){
				$page_access = 0 ;
			}
		}	
 //	echo $session->get('application_page');		die;
 //	 echo $page_access;die;
 

		
 
			if($page_access ==1)	
			return redirect()->to(base_url()."/accessDenied");
			
		 
	}
 
    //--------------------------------------------------------------------
 
    public function after(RequestInterface $request, ResponseInterface $response, $arguments = null)
    {
        // Do something here
    }
}

