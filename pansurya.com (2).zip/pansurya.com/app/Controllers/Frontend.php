<?php

namespace App\Controllers;
use App\Models\FollowerModel;
use App\Models\ServiceModel;

class Frontend extends BaseController
{


    public function __construct()
	{
    $this->followerModel = new  FollowerModel();
    $this->serviceModel = new ServiceModel();
    }

    public function index(){
        
        $data['follower'] =$this->followerModel->getReq();
        return view('frontend_pages/index',$data);
    }
            public function follow()
            {
           
             
              return view('frontend_pages/follow');
            
            }
          
            public function  add()
            {  
           
                $data['record'] = array();
                // print_r($data['record']);die;
               
                    $result = $this->followerModel->getReq();
                  
                            $this->followerModel->saveRequset();   
                        return redirect()->to(base_url().'public/follower');      
           }          
    public function service(){
         $data['servs'] = $this->serviceModel->getImage();
    //  echo "<pre>";print_r($data['servs']);die;
                return view('frontend_pages/Services',$data);
            }
            
     public function contact(){

        $data['record'] =$this->followerModel->getCon();
        // print_r( $data['record']);die;
        
        return view('frontend_pages/contact',$data);
     }  
     

     public function save()
     {  
     
        $this->followerModel->saveCont();   
                   return redirect()->to(base_url().'public/contact');
     
    }

}