<?php

namespace App\Controllers;
 use App\Models\FollowerModel;
 use App\Models\ServiceModel;


class Dashboard extends BaseController
{

     public function __construct()
	 {
		$this->session = session();
		$this->followerModel = new FollowerModel();
       $this->serviceModel = new  ServiceModel();

	  
		
 }
    

    public function index()
    {
        $data['follower'] =$this->followerModel->getReq();
        $data['serv'] = $this->serviceModel->getdetaile();
        // print_r( $data['serv'] );die;
	
        return view('dashboard',$data);
    }
}
