<?php

namespace App\Controllers;
 


class  Contact  extends BaseController
{

    
    

    public function index()
    {
        // echo "hi";die;
	
        return view('contact/conta_detailes');
    }
    public function add()
    {
        // echo "hi";die;
	
        return view('contact/add_contact');
    }


}
