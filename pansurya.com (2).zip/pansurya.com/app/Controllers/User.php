<?php

namespace App\Controllers;
use App\Models\UserModel;

class User extends BaseController
{
        public function __construct()
	{
        
            $this->userModel = new UserModel();
            $this->db = db_connect();
            $this->table = "admin_login"; 
            $request = \Config\Services::request();
                 $this->session = session();
         }
		


        public function index(){

            return view('login');

        }
    public function auth(){
    
        $data =  $this->userModel->checkLogin(); 
        // print_r($data);die;
        return redirect()->to(base_url().'public/'.$data);

    }
   
    public function logout()
    {
    //echo "hi";die; 
        $this->session->destroy();
        return redirect()->to(base_url().'admin');
        
        }
        public function profile()
    {
   
        return view('users/app_profile');
       
        
        }
        public function forgot_pass()
        {
    
            return view('users/app_profile');
           
            
            }
    
}