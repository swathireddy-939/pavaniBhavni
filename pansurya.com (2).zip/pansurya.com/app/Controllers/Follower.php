<?php

namespace App\Controllers;
use CodeIgniter\HTTP\RequestInterface;
use CodeIgniter\HTTP\ResponseInterface;
use App\Models\FollowerModel;


class Follower extends BaseController
{


    public function __construct()
	{
		
		$this->followerModel = new  FollowerModel();
		$this->request = \Config\Services::request();
			
		
	}
 

    public function  index()
{  
	
    $data['follower'] =$this->followerModel->getReq();
    //   print_r($data['follower']);die();
        return view('follower/followers_detailes',$data);
}
 public function  view($id){
    // echo $id;die;
    $data = $this->followerModel->getReq($id);
    $data['view'] = $data[0];
       
    return view('follower/view_followers',$data);
 }


    
}  