<?php

namespace App\Controllers;
use App\Models\ServiceModel;

class Service extends BaseController
{



    public function __construct()
	{
		
		$this->serviceModel = new  ServiceModel();
		$this->request = \Config\Services::request();
			
		
	}
    public function index()
    {
   
        $data['serv'] = $this->serviceModel->getServ();
		//  echo" <pre>";print_r($data['serv']);die;
        
        return view('service/service_detailes',$data);
    }

   

public function add($ser_id="")
{
    print_r($ser_id);die;
    
    $data['record'] = array();
   
    
    if($ser_id!=""){

        $result = $this->serviceModel->getServ($ser_id);
        // print_r($result);die;
        $data['record'] = $result[0];
        //   print_r($data['record']);die();

  
            }else if($this->request->getVar('action_type')!=""){
                $ser_id = $this->serviceModel->saveService();   
            return redirect()->to(base_url().'public/services');
   }
           $data['ser_id'] = $ser_id;

           return view('service/add_service',$data);

}


public function view($id)
	{
   
		// echo $id;die;
		
	  $data['serv'] = $this->serviceModel->getdetaile($id);
	//  echo "<pre>"; ($data['serv']);die;
	
	
		 
	//   print_r($data['view']);die;																							
		  
	  return view('service/view_service',$data);
  
	}

public function upload(){
    $this->serviceModel->saveService();
}

    public function upload_1(){

    
$output_dir =  ROOTPATH."public/uploads/service"; 
if(isset($_FILES["myfile"]))
{
	$ret = array();
	
//	This is for custom errors;	
/*	$custom_error= array();
	$custom_error['jquery-upload-file-error']="File already exists";
	echo json_encode($custom_error);
	die();
*/
	$error =$_FILES["myfile"]["error"];
	//You need to handle  both cases
	//If Any browser does not support serializing of multiple files using FormData() 
	if(!is_array($_FILES["myfile"]["name"])) //single file
	{
 	 	$fileName = $_FILES["myfile"]["name"];
 		move_uploaded_file($_FILES["myfile"]["tmp_name"],$output_dir.$fileName);
    	$ret[]= $fileName;
	}
	else  //Multiple files, file[]
	{
	  $fileCount = count($_FILES["myfile"]["name"]);
	  for($i=0; $i < $fileCount; $i++)
	  {
	  	$fileName = $_FILES["myfile"]["name"][$i];
		move_uploaded_file($_FILES["myfile"]["tmp_name"][$i],$output_dir.$fileName);

	  	$ret[]= $fileName;
	  }
	
	}
    echo json_encode($ret);
 }
 
    }
}