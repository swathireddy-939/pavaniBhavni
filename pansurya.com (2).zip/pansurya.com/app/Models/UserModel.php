<?php 
namespace App\Models;
use CodeIgniter\Model;
 
class UserModel extends Model{
   
 protected $table ="admin_login";   
protected $primaryKey = "id";
protected $allowedFields = ['status']; 


public function __construct() {
    
    $this->db = db_connect();
    $this->table = "admin_login"; 
    $request = \Config\Services::request();
		 $this->session = session();

}
 public function getUserDetails($email = '',$password = ''){
		
    
    $data = array();

    
    if($email !=""){
        $builder  = $this->db->table($this->table.' l');
        // print_r($builder);
        $builder->select("l.*");
       
        $builder->Where("l.email", $email);
        $result = $builder->get();
        // echo $this->db->getLastQuery();die;
        if($result->getNumRows() > 0){
            $data = $result->getRowArray();
        //    echo "<pre>"; print_r($data);die;
        }

    }
    return $data;
   }





   public function getUsers($user_id = false) {

    $builder  = $this->db->table($this->table.' l');
    // print_r($builder);die;
    		$builder->select("l.*");
    		$builder->where('id',$user_id);
    		$result = $builder->get();
       
    		 if($result->getNumRows() > 0){
    		   $data = $result->getRowArray();
            // print_r($data);die;
               return $data;
     
    	   }
           
      
    }
    
 public function checkLogin(){	
		$request = \Config\Services::request();
		$session = session();
        
     $email = $request->getVar('email'); 
    
     $password =  $request->getVar('password');
    	 $data = $this->getUserDetails($email);
  
 	 if(count($data)>0){      
			$pass = $data['password']; 
	        $verify_pass = password_verify($password, $pass);
            // echo "<pre>";print_r($verify_pass);die;
			
            if($verify_pass){

    //   echo "<pre>";print_r($verify_pass);die;
                $ses_data = [
                    'id'         => $data['id'],
                    'email'      => $data['email'],
                    'mobile'     => $data['mobile'],
                    'name'       => $data['name'],
                    'role_id'       => $data['role_id'],
                 
                   
                    ];
             
                        // print_r($ses_data);die;
                   
                    $this->session->set($ses_data);
          
			    
                        return 'dashboard';
				
            }else{

                // echo "inavlid pass";
				 
                $this->session->setFlashdata('msg', 'Wrong Password');
                
            }
            
		   
            
		 }else{
		     
		      $this->session->setFlashdata('msg', 'Your account has been deactivated. Please contact to System Administrator.');
		     
		 }    
            
        
         return 'admin';
     
    
	}

 

// public function updateProfileImage()
// 	{
	   
// 		$request = \Config\Services::request();
// 	    $user_id = $request->getVar('user_id');
	    
// 	    $result = $this->getUsers($user_id);
	    
		
// 		if(count($result)>0){
		                
// 	        $root_path = ROOTPATH."public/uploads/profile_images/";
   
//             $files = $request->getFiles();
          
//             $pro_image = $files['pro_image'];
//             // 
//             $pro_image_name = "";
          
//             if($pro_image->isValid()){
                
//                  $pro_image = $request->getFile('pro_image');
                
//     			 if (!is_null($pro_image)){
    
//                $pro_image_name = $pro_image->getRandomName();
             
//                $pro_image->move($root_path,$pro_image_name);
//     				 $pro_image_name = $pro_image_name;
//     				 echo $pro_image_name;die;
//      		     }	
 		     
//             }
            
//             if($pro_image_name!=""){
//                	$query  = "update ".$this->table." set profile_img ='".$pro_image_name."' where id=".'"' . $user_id . '"';
//                 $this->db->query($query);
//     			$this->session->setFlashdata('msg', 'Profile Image has been updated successfully.');
//             }
// 		}
		
// 		return 0;
// 	}


}
