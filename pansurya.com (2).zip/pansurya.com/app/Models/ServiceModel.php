<?php

namespace App\Models;
use CodeIgniter\Model;



class  ServiceModel extends Model
{
   
    protected $primaryKey = "id";
    protected $allowedFields = ['status'];


 	public function __construct() {
		 $this->db = db_connect(); 
		 $this->detailes_table = "ps_detailes";
		 $this->image_table ="ps_image";
		 $this->table = "ps_service";
		 $request = \Config\Services::request();
		 $this->session = session();
		// $builder = $db->table($this->table);	
	}
	public function getServ($ser_id=false) {
      
        $result = array(); 
		$builder  = $this->db->table($this->detailes_table.' p');
		$builder->select('p.*, d.pro_image');
		$builder->join($this->image_table.' d', 'd.serivce_id = p.id','left');
        if($ser_id != "")
		{
			$builder->where('p.id', $ser_id);
		}
		$builder->groupBy('d.serivce_id', $ser_id);

		$builder->where('p.status',0);
		$query = $builder->get();
		        // echo $this->db->getLastQuery();die;

        if($query->getNumRows() > 0){
		$result  = $query->getResultArray();  
		// echo "<pre>";print_r($result);
		return $result;
        
      }
    }
	public function getdetaile($ser_id=false) {
     
        $result = array(); 
		$builder  = $this->db->table($this->detailes_table.' d');
	
		$builder->select('d.*,e.pro_image');
		$builder->join($this->image_table.' e', 'e.serivce_id = d.id','left');

		
        if($ser_id != "")
		{
			$builder->where('d.id', $ser_id);
		}
			
		$builder->where('d.status',0);
		$query = $builder->get();
        if($query->getNumRows() > 0){
		$result  = $query->getResultArray();  
		// echo "<pre>";print_r($result);
		return $result;
        
      }
    }
	public function getImage($ser_id=false) {
    //   echo $ser_id;die;
        $result = array(); 
		$builder  = $this->db->table($this->image_table.' i');
		$builder->select('i.*');
        if($ser_id != "")
		{
			$builder->where('i.serivce_id', $ser_id);
		}
		$builder->where('i.status',0);
		$query = $builder->get();
        if($query->getNumRows() > 0){
		$result  = $query->getResultArray();  
		//  echo $this->db->getLastQuery();die;
		return $result;
        
      }
    }
	
 	public function saveService()
	{
		$request = \Config\Services::request();
		$insert_id = "";
		$action_type ="";
		$id ="";

		// echo "<pre>";print_r($request);die;
	
		$ser_id= $request->getVar('ser_id');
		$action_type = $request->getVar('action_type'); 
	 
			
			$data  = [

				        'pro_name' => $request->getPost('pro_name'),
						'pro_date' => $request->getPost('pro_date'),
						'status' => 0
						
		
			  ];

			  try{ 

				if($action_type =="edit" && $id!=""){
					
					$this->db->table($this->detailes_table)->update($data,'id='.$id);
					$insert_id = $ser_id;
					
						$this->session->setFlashdata('msg', 'Updated successfully');
					
				}else{
					
					$this->db->table($this->detailes_table)->insert($data);
					$insert_id =  $this->db->insertID(); 
				}
				
				
				$this->session->setFlashdata('msg', 'Inserted successfully');
				
				
			}catch(\Exception $e){
				
					$this->session->setFlashdata('msg', 'Something went wrong');
				}
				// echo $this->db->getLastQuery();die;
              $data=[];
              $root_path =  ROOTPATH."public/uploads/service"; 
			   
			             $files = $request->getFiles();
					//	echo "<pre>"; print_r($files);die;
						 $k=0;
						 foreach($files['pro_image'] as $file){

						
                        //  print_r($files);die;

		                      //   $pro_image = $file['pro_image'];

                                if($file->isValid()){
                                 
    				            // $pro_image = $request->getFile('pro_image')[$k];
        						// if (!is_null($pro_image)){
        	 
                                    $pro_image_name = $file->getRandomName();
            						$file->move($root_path,$pro_image_name);
            						 $data['pro_image'] = $pro_image_name;
     						 //}					
                    }
                   
				try{ 

					$data['serivce_id']=$insert_id;

					if($action_type =="edit" && $id!=""){
						
						$this->db->table($this->image_table)->update($data,'id='.$id);
						//$insert_id = $ser_id;
						
							$this->session->setFlashdata('msg', 'Updated successfully');
						
					}else{
						
						$this->db->table($this->image_table)->insert($data);
						//$insert_id =  $this->db->insertID(); 
					}
					
					
					$this->session->setFlashdata('msg', 'Inserted successfully');
					
					
				}catch(\Exception $e){
					
						$this->session->setFlashdata('msg', 'Something went wrong');
					}
					$k++;
				}

              
				return $insert_id;
	}
}
	

	
	
