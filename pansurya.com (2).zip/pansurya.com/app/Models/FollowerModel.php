<?php

namespace App\Models;
use CodeIgniter\Model;
class  FollowerModel extends Model
{ 
    protected $table ='ps_follower';
    protected $primaryKey ="id";
    protected $allowedFields = ['status'];

public function __construct() {
    $this->db =db_connect(); 
    $this->table ="ps_follower";
    $this->ps_cont ="ps_contact";
    $request = \Config\Services::request();
    $this->session = session();
   // $builder = $db->table($this->table);	
}
public function getReq($id_ci= "") {
//  echo "hi";die;
    $result = array(); 
    $builder  = $this->db->table($this->table.' f');
  
    $builder->select('f.*,');
    if($id_ci != "")
    {
      // echo $id_ci;die;
        $builder->where('f.id', $id_ci);
    }
    $builder->where('f.status',0);
    $query = $builder->get();
    $result  = $query->getResultArray();  
    // echo "<pre>";print_r($result);
    return $result;
    
  }

  



  public function saveRequset()
  {
    //  echo"going";die;
      $insert_id = "";
 
          $request = \Config\Services::request();
        //   print_r($request);die;
        
          $data  = [
 
                      'f_name'     => $request->getVar('f_name'),
                      'f_moblie'   => $request->getVar('f_moblie'),
                      'f_mandal'   => $request->getVar('f_mandal'),
                      'f_panchayathi'   => $request->getVar('f_panchayathi'),
                      'f_village'   => $request->getVar('f_village'),
                     

                      'status' => 0
            ];
            //  print_r($data);die;
            $root_path =  ROOTPATH."public/uploads/followers";  
            $files = $request->getFiles();
                  // print_r($files);die;

                      $follow_image = $files['follow_image'];
                      // print_r($follow_image);die;

                         if($follow_image->isValid()){
                          
                  $follow_image = $request->getFile('follow_image');
              if (!is_null($follow_image)){
    
                  $follow_image_name = $follow_image->getRandomName();
                  $follow_image->move($root_path,$follow_image_name);
                  $data['follow_image'] = $follow_image_name;
           }					
             }
              try{      $this->db->table($this->table)->insert($data);
                           
                  $this->session->setFlashdata('msg', 'Inserted successfully');
              }
                  
              catch(\Exception $e){
                  
                      $session->setFlashdata('msg', 'Something went wrong');
                  }
              return $insert_id;
                }

                public function getCon() {
                  //  echo "hi";die;
                      $result = array(); 
                      $builder  = $this->db->table( $this->ps_cont.' c');
                    
                      $builder->select('c.*,');
                      // if($id_ci != "")
                      // {
                      //   // echo $id_ci;die;
                      //     $builder->where('c.id', $id_ci);
                      // }
                      $builder->where('c.status',0);
                      $query = $builder->get();
                      $result  = $query->getResultArray();  
                      // echo "<pre>";print_r($result);
                      return $result;
                      
                    }
                  


   public function saveCont()
  {
    //  echo"going";die;
      $insert_id = "";
       
 
          $request = \Config\Services::request();
        //   print_r($request);die;
        
          $data  = [
 
                      'first-name'     => $request->getVar('first-name'),
                      'email'   => $request->getVar('email'),
                      'phone'   => $request->getVar('phone'),
                      'description'   => $request->getVar('description'),
                      'status' => 0
            ];
            //  print_r($data);die;
            
              try{    
                
                $this->db->table($this->table)->insert($data);
                           
                  $this->session->setFlashdata('msg', 'Inserted successfully');
              }
                  
              catch(\Exception $e){
                  
                      $session->setFlashdata('msg', 'Something went wrong');
                  }
              return $insert_id;
                }

}