
<?php   
$this->session = session();


if(in_array($this->session->get(''),array())){
     

}     

?>

<?php echo view('includes/header');?>
<!--**********************************
    Nav header end
***********************************-->		      
<!--**********************************
    Header start
***********************************-->
<?php echo view('includes/top_right_menu');?>
<!--**********************************
    Header end ti-comment-alt
***********************************-->        <!--**********************************
    Sidebar start
***********************************-->
<?php echo view('includes/leftmenu');?>
<!--**********************************
    Sidebar end
***********************************-->        <!--**********************************
    Content body start
***********************************-->
<div class="content-body">
    <!-- row -->
	<div class="container-fluid">
		<div class="form-head mb-4">
			<h2 class="text-black font-w600 mb-0">Dashboard</h2>
		</div>
		<div class="row">
			<div class="col-xl-4 col-sm-6">
				<div class="card">
					<div class="card-body">
						<div class="media align-items-center invoice-card">
							<div class="media-body">
								<h2 class="fs-38 text-black font-w600"></h2>
								<span class="fs-18">Service</span>
							</div>
							<span class="h1 text-warning">
								<i class="flaticon-381-user-4"></i>
							</span>
						</div>
					</div>
				</div>
			</div>
			<div class="col-xl-4 col-sm-6">
				<div class="card">
					<div class="card-body">
						<div class="media align-items-center invoice-card">
							<div class="media-body">
								<h2 class="fs-38 text-black font-w600"></h2>
								<span class="fs-18">MY follower</span>
							</div>
							<span class="h1 text-success">
								<i class="flaticon-381-like"></i>
							</span>
						</div>
					</div>
				</div>
			</div>
			
			
<!--
			
			<div class="col-xl-12">
				<div class="d-sm-flex  d-block align-items-center mb-4">
					<div class="me-auto">
						<h4 class="fs-20 text-black">Order History</h4>
					</div>
					<div class="dropdown custom-dropdown mb-0 mt-3 mt-sm-0">
						<div class="btn btn-light btn-rounded" role="button" data-bs-toggle="dropdown" aria-expanded="false">
							<i class="las la-calendar-alt scale5 me-3"></i>
							Filter Date
							<i class="fa fa-caret-down text-primary ms-3" aria-hidden="true"></i>
						</div>
						<div class="dropdown-menu dropdown-menu-end">
							<a class="dropdown-item" href="javascript:void(0);">Details</a>
							<a class="dropdown-item text-danger" href="javascript:void(0);">Cancel</a>
						</div>
					</div>
				</div>
			</div>
			<div class="col-12">
                <div class="card">
                    <div class="card-body">
                        <div class="table-responsive table-hover fs-14">
					<table class="table display mb-4 dataTablesCard " id="example5">
						<thead>
							<tr>
								<th>Order ID</th>
								<th>Date</th>
								<th>Item Name</th>
								<th>Amount</th>
								<th>Status</th>
								<th>Action</th>
							</tr>
						</thead>
						<tbody>
							<tr>
								<td><span class="text-black font-w500">#123412451</span></td>
								<td><span class="text-black text-nowrap">#June 1, 2020, 08:22 AM</span></td>
								<td>
									<div class="d-flex align-items-center">
										<img src="public/assets/images/avatar/25.png" alt="" class="rounded-circle me-3" width="50">
										<div>
											<h6 class="fs-16 text-black font-w600 mb-0 text-nowrap">item Name</h6>
										</div>
									</div>
								</td>
								<td><span class="text-black"><strong>₹ 500/-</strong></span></td>
								<td><a href="javascript:void(0)" class="btn btn-success btn-rounded">Completed</a></td>
								<td>
									<div class="d-flex">
												<a href="orderonline_view.html" class="btn btn-success btn-xs me-1 shadow sharp"><i class="fa-expand fas"></i></a>
												<a href="#" class="btn btn-danger shadow btn-xs sharp"><i class="fas fa-trash-alt"></i></a>
											</div>												
										</td>	
							</tr>
							<tr>
								<td><span class="text-black font-w500">#123412451</span></td>
								<td><span class="text-black text-nowrap">#June 1, 2020, 08:22 AM</span></td>
								<td>
									<div class="d-flex align-items-center">
										<img src="public/assets/images/avatar/19.png" alt="" class="rounded-circle me-3" width="50">
										<div>
											<h6 class="fs-16 font-w600 mb-0 text-nowrap"><a href="javascript:void(0)" class="text-black">Item Name</a></h6>
										</div>
									</div>
								</td>
								<td><span class="text-black"><strong>₹ 300/-</strong></span></td>
								<td><a href="javascript:void(0)" class="btn btn-warning btn-rounded">Pending</a></td>
								<td>
									<div class="d-flex">
												<a href="orderonline_view.html" class="btn btn-success btn-xs me-1 shadow sharp"><i class="fa-expand fas"></i></a>
												<a href="#" class="btn btn-danger shadow btn-xs sharp"><i class="fas fa-trash-alt"></i></a>
											</div>												
										</td>
							</tr>
							<tr>
								<td><span class="text-black font-w500">#123412451</span></td>
								<td><span class="text-black text-nowrap">#June 1, 2020, 08:22 AM</span></td>
								<td>
									<div class="d-flex align-items-center">
										<img src="public/assets/images/avatar/20.png" alt="" class="rounded-circle me-3" width="50">
										<div>
											<h6 class="fs-16 font-w600 mb-0 text-nowrap"><a href="javascript:void(0)" class="text-black">Item Name</a></h6>
										</div>
									</div>
								</td>
								<td><span class="text-black"><strong>₹ 400/-</strong></span></td>
								<td><a href="javascript:void(0)" class="btn btn-dark btn-rounded">Canceled</a></td>
								<td>
									<div class="d-flex">
												<a href="orderonline_view.html" class="btn btn-success btn-xs me-1 shadow sharp"><i class="fa-expand fas"></i></a>
												<a href="#" class="btn btn-danger shadow btn-xs sharp"><i class="fas fa-trash-alt"></i></a>
											</div>												
										</td>
							</tr>
						</tbody>
					</table>
				</div>
                    </div>
                </div>
            </div>
-->
		</div>
    </div>
</div>
<!--**********************************
    Content body end
***********************************-->
        <!--**********************************
    Footer start
***********************************-->

<!--**********************************
    Footer end
***********************************-->        
<?php echo view('includes/footer');?>