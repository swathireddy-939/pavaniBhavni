<?php echo view('includes/header');?>	      
<!--**********************************
    Header start
***********************************-->
<?php echo view('includes/top_right_menu');?>
<!--**********************************
    Header end ti-comment-alt
***********************************-->        <!--**********************************
    Sidebar start
***********************************-->
<?php echo view('includes/leftmenu');?>
<!--**********************************
    Sidebar end
***********************************-->        <!--**********************************
    Content body start
***********************************-->
		
<div class="content-body">
                <!-- row -->
         <div class="container-fluid">
		<div class="page-titles">
			<div class="row">
				<div class="col-auto col-lg-9 m-auto text-center">
					<ol class="breadcrumb pt-2">
						<li class="breadcrumb-item"><a href="javascript:void(0)">Dashboard</a></li>
						<li class="breadcrumb-item"><a href="javascript:void(0)">Followers officer</a></li>
						<li class="breadcrumb-item active"><a href="javascript:void(0)">View followers officer</a></li>
					</ol>
				</div>
				<div class="col-lg-3">
					<div class="clearfix float-lg-end text-center">
						<!-- <a href="add_verified.html" class="btn btn-primary light"><i class="fa fa-reply"></i> </a>
						
						<a href="verified.html" class="btn btn-primary light ms-2"><i class="fas fa-save px-2"></i>Save</a> -->
					</div>
				</div>
			</div>
        </div>
		<!-- row -->
		<div class="row">
			<div class="col-xl-12">
				<div class="card">
					<div class="row">
						<div class="col-md-12">
					    <div class="card-body">
                        <img class="card-img-top" src="<?php echo base_url();?>public/uploads/followers/<?php echo $view['follow_image']; ?>"  alt="">
									
                                   
						<ul>
							
							<li> <strong>Name:<?php echo $view['f_name']; ?></strong></li>
							<li> <strong>Mobile:<?php echo $view['f_moblie']; ?></strong> </li>
							<li> <strong>Mandal:<?php echo $view['f_mandal']; ?></strong>  </li>
							<li> <strong>Panchayathi:<?php echo $view['f_panchayathi']; ?></strong>  </li>
							<li> <strong>vilage:<?php echo $view['f_village']; ?></strong> </li>
					
							
						</ul>
					</div>
							
						</div>
						
						
						
					</div>
					
				</div>
			</div>
		</div>
		
	</div>
            </div>		
		

<!--**********************************
    Content body end
***********************************-->
        <!--**********************************
    Footer start
***********************************-->
<?php echo view('includes/footer');?>