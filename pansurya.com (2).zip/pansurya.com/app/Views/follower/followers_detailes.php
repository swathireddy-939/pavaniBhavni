<?php echo view('includes/header');?>
<!--**********************************
    Nav header end
***********************************-->		      
<!--**********************************
    Header start
***********************************-->
<?php echo view('includes/top_right_menu');?>
<!--**********************************
    Header end ti-comment-alt
***********************************-->        <!--**********************************
    Sidebar start
***********************************-->
<?php echo view('includes/leftmenu');?>
<!--**********************************
    Sidebar end
***********************************-->        <!--**********************************
    Content body start
***********************************-->
		
<div class="content-body">
                <!-- row -->
         <div class="container-fluid">
		<div class="page-titles">
			<div class="row">
				<div class="col-auto col-lg-9 m-auto text-center">
					<ol class="breadcrumb pt-2">
						<li class="breadcrumb-item"><a href="javascript:void(0)">Dashboard</a></li>
						<li class="breadcrumb-item active"><a href="javascript:void(0)">Followers</a></li>
					</ol>
				</div>
				<div class="col-lg-3">
					<div class="clearfix float-lg-end text-center">
<!--						<a href="javascript:void()" class="btn btn-primary light"><i class="fa fa-reply"></i> </a>-->
						
						<!-- <a href="add_verified.html" class="btn btn-primary light ms-2"><i class="fas fa-add px-2"></i>Add Verified officer</a> -->
					</div>
				</div>
			</div>
        </div>
		<!-- row -->
		<div class="row">
                <div class="card">
                    <div class="card-body">
                        <div class="table-responsive table-hover fs-14">
					<table class="table display mb-4 dataTablesCard " id="example5">
						<thead>
							<tr>
								<th>S.NO</th>
								<th>Name</th>
								<th>image</th>
								<th>Mobile</th>
								<th>Mandal</th>
								<th>panchayathi</th>
								<th>Action</th>
							</tr>
						</thead>
						<tbody>
							<tr><?php

								 foreach ($follower as $row) { ?>
								<td><span class="text-black font-w500"> <?php echo $row['id']; ?> </span></td>
<!--								<td><span class="text-black text-nowrap">#June 1, 2020, 08:22 AM</span></td>-->
                              <td><span class="text-black font-w500"><?php echo $row['f_name']; ?></span></td>
								<td>
									<div>
										<img src="<?php echo base_url()?>public/uploads/followers/<?php echo $row['follow_image']; ?>" alt="" class="rounded-circle me-3" height="50px"  width="50">
										<div>
											<h6 class="fs-16 text-black font-w600 mb-0 text-nowrap"></h6>
										</div>
									</div>
								</td>
								
								<td><span class="text-black"><strong><?php echo $row['f_moblie']; ?></strong></span></td>
								<td><span class="text-black"><strong><?php echo $row['f_mandal']; ?></strong></span></td>
								<td><span class="text-black"><strong><?php echo $row['f_panchayathi']; ?></strong></span></td>
								<td>
									<div class="d-flex">
												<a href="<?php echo base_url() ?>public/follower/view/<?php echo $row['id']; ?>" class="btn btn-success btn-xs me-1 shadow sharp"><i class="fa-expand fas"></i></a>
										<!-- <a href="add_verified.html" class="btn btn-primary shadow btn-xs sharp me-1"><i class="fas fa-pencil-alt"></i></a> -->
												<a href="#" class="btn btn-danger shadow btn-xs sharp"><i class="fas fa-trash-alt"></i></a>
											</div>												
										</td>	
							</tr>
							
							<?php }?>
						</tbody>
					</table>
				</div>
                    </div>
                </div>
            </div>
				
	</div>
            </div>		

<!--**********************************
    Content body end
***********************************-->
        <!--**********************************
    Footer start
***********************************-->
<?php echo view('includes/footer');?>