<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta charset="utf-8">
    <meta name="keywords" content="">
	<meta name="author" content="">
	<meta name="robots" content="">
	<meta name="format-detection" content="telephone=no">
    <title> :: PAN SURYA :: </title>
    <!-- Favicon icon -->
	
	<link rel="icon" type="image/png" sizes="16x16" href="<?php echo base_url() ?>/assets/images/favicon.png">	
		 <link href="<?php echo base_url() ?>assets/vendor/jqvmap/css/jqvmap.min.css" rel="stylesheet" type="text/css">
		 <link href="<?php echo base_url() ?>assets/vendor/chartist/css/chartist.min.css" rel="stylesheet" type="text/css">	
		 <link href="<?php echo base_url() ?>assets/vendor/owl-carousel/owl.carousel.css" rel="stylesheet" type="text/css">	
		 <link href="<?php echo base_url() ?>assets/vendor/bootstrap-select/dist/css/bootstrap-select.min.css" rel="stylesheet" type="text/css">	
		 <link href="<?php echo base_url() ?>assets/css/style.css" rel="stylesheet" type="text/css">
        
</head>
<?php
$this->session = session();?>
<?php if(session()->getFlashdata('msg')):?>
                    <div class="alert alert-danger"><?= session()->getFlashdata('msg') ?></div>
                <?php endif;?>
			
<body class="h-100 login_page">
    <div class="authincation h-100">
        <div class="container h-100">
            <div class="row justify-content-center h-100 align-items-center">
                <div class="col-md-6 mt-lg-5">
                    <div class="authincation-content">
                        <div class="row no-gutters">
                            <div class="col-xl-12">
                                <div class="auth-form">
									<div class="text-center mb-3">
										<a href="index.htm"><img src="<?php echo base_url()?>assets/images/login-logo.png" alt=""></a>
									</div>
                                    <h4 class="text-center mb-4 text-white">Sign in your account</h4>
                                    <form action="<?php  echo base_url(); ?>public/login/auth" method="post" id="loginvalidation">
                                        <div class="form-group">
                                            <label class="mb-1 text-white"><strong>User ID</strong></label>
                                            <input type="email" class="form-control" id="email" name="email">
                                        </div>
                                        <div class="form-group">
                                            <label class="mb-1 text-white"><strong>Password</strong></label>
                                            <input type="password" class="form-control" id="inputPassword" maxlength="6" name="password">
                                        </div>
                                        <div class="form-row d-flex justify-content-between mt-4 mb-2">
                                            <div class="form-group">
                                               <div class="custom-control custom-checkbox ms-1 text-white">
													<input type="checkbox" class="form-check-input" onClick="showPassword()" id="basic_checkbox_1">
													<label class="custom-control-label"  for="basic_checkbox_1" >Show a Password</label>
												</div>
                                            </div>
                                            <div class="form-group">
                                                <a class="text-white" href="page_forgot_password.html">Forgot Password?</a>
                                            </div>
                                        </div>
                                        <div class="text-center">
                                        <button type="submit" class="btn bg-white text-primary btn-block">Sign Me In</button>
                              
                                        </div>
                                    </form>
<!--
                                    <div class="new-account mt-3">
                                        <p class="text-white">Don't have an account? <a class="text-white" href="page_register.html">Sign up</a></p>
                                    </div>
-->
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

	<?php echo view('includes/footer');?>
    <script>
   function showPassword() {  
      // alert();
        var x = document.getElementById("inputPassword");
        if (x.type === "password") {
            x.type = "text";
        } else {
            x.type = "password";
           
        }
    }


	</script>
	

	