﻿<?php echo view('includes/frontend_header'); ?>
<!-- START HEADER --> 

<!-- START SECTION BANNER -->





<!-- START SECTION CONTACT -->
<div  class="section bg_redon">
	<div class="container">
		
		<div class="heading_s1 text-center mt-5 pb-5 ">
                	<h2>We Stand With You</h2>
                </div>
		
    	<div class="row">
        	<div class="col-lg-12">
            <div class="field_form contact_form">
                <form method="post" action="<?php echo base_url();?>public/savefollow" enctype="multipart/form-data">
                        <div class="row">
                            <div class="form-group col-md-8">
                                <input  placeholder="Enter Name *" id="f_name" class="form-control rounded-0" name="f_name" value="<?php echo (isset($record['f_name']) ? $record['f_name']: ""); ?>" type="text">
                             </div>
							<div class="form-group col-md-4">
                                <input placeholder="Enter Phone No. *" id="f_moblie" class="form-control rounded-0" value="<?php echo (isset($record['f_moblie']) ? $record['f_moblie']: ""); ?>"  name="f_moblie">
                            </div>
							
                            <div class="form-group col-md-4">
                                <input  placeholder="Enter Mandal *" class="form-control rounded-0" name="f_mandal" value="<?php echo (isset($record['f_mandal']) ? $record['f_mandal']: ""); ?>"  type="text">
                            </div>
							 <div class="form-group col-md-4">
                                <input placeholder="Enter panchayathi *"  class="form-control rounded-0" name="f_panchayathi" value="<?php echo (isset($record['f_panchayathi']) ? $record['f_panchayathi']: ""); ?>"  type="text">
                            </div>
							
							 <div class="form-group col-md-4">
                                <input  placeholder="Enter village *" id="f_village" class="form-control rounded-0" name="f_village" value="<?php echo (isset($record['f_village']) ? $record['f_village']: ""); ?>"  type="text">
                            </div>
							
                            
							<div class="form-group col-md-6">
								<label for="">User Photo</label>
                                <input  placeholder="Enter Phone No. *" id="follow_image" class="form-control rounded-0" name="follow_image" type="file"  value="<?php echo (isset($record['follow_image']) ? $record['follow_image']: ""); ?>" accept="image/gif, image/jpeg, image/png">
                            </div>
							
                            <div class="col-md-12">
                            <!-- <?php 
                                                      // Display existing image if available
                                                        //  $image_url = base_url() . "public/uploads/followers";
                                                        //        if (!empty($record['follow_image'])) {
                                                        //  $image_url .= $record['follow_image'];
                                                        //  echo '<img src="' . $image_url . '" alt="Current Image">';
                                                        // }
                                                           ?> -->
														 
                          
                                <button type="submit" class="btn btn-default rounded-0 float-right">Submit</button>
                            </div>
                            <!-- <div class="col-md-12">
                                <div id="" class="alert-msg text-center"></div>
                            </div> -->
                        </div>
                  
                </div>
             </form>		
            </div>
        </div>
    </div>
</div>
<!-- START SECTION CONTACT -->

<!-- START FOOTER SECTION --> 
<?php echo view('includes/frontend_footer'); ?>