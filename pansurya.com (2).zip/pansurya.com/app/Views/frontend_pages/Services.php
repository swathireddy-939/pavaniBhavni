﻿<?php echo view('includes/frontend_header'); ?>

<!-- START HEADER --> 


<!-- START SECTION PORTFOLIO -->
<div id="portfolio" class="section pb_70 bg_redon">
    <div class="container">
		<div class="row justify-content-center mt-5 pb-3">
        	<div class="col-xl-6 col-lg-7 col-md-9 text-center text-lg-left">
            	<div class="heading_s1">
                	<h2>Program name</h2>
                </div>
            </div>
			
			<div class="col-xl-6 col-lg-7 col-md-9 text-center text-lg-right">
            	<div class="heading_s1">
                	<h2> <span>Date :</span>11:03:24</h2>
                </div>
            </div>
        </div>
		
        <div class="row">
            <div class="col-md-12">
            	
                <ul class="grid_container gutter_medium work_col3 portfolio_gallery portfolio_style1 masonry">
                	
                    <!-- START PORTFOLIO ITEM -->
                    <?php  
                    if($servs!==null) foreach($servs as $serv){?>
					<li class="grid_item">
                        <div class="portfolio_item">
                        
                            <a href="#" class="image_link">
                                <img src="<?php echo base_url() ?>public/uploads/service/<?php echo $serv['pro_image'];?>" alt="image" >
                            </a>
                                <div class="portfolio_content">
                                    <div class="link_container">
                                        <a href="<?php echo base_url() ?>public/uploads/service/<?php echo $serv['pro_image'];?>" class="image_popup"><i class="ion-image"></i></a>
                                    </div>
                              </div>
                           
                        </div>
                    </li>
                    <?php }
                  else {
                    echo "<tr><td colspan='4'></td></tr>";
                }?>
                </ul>
                
            </div>
        </div>
    </div>
    <div class="portfolio_modal modal fade" id="pr_modal">
    	<div class="modal-dialog modal-xl modal-dialog-centered">	
        	<div class="modal-content">
            	<div class="modal-body">
                	<button type="button" class="close" data-dismiss="modal" aria-label="Close">
                      <span aria-hidden="true">×</span>
                    </button>
                    <div class="row">
                        <div class="col-12">
                            <div class="pf_content">	
                                <div class="heading_s1">
                                    <h2>Portfolio Title</h2>
                                </div>
                                <p>Nam eget neque pellentesque efficitur neque at, ornare orci. Vestibulum ligula orci volutpat id aliquet eget, consectetur eget ante. Duis pharetra for nec rhoncus felis sagittis nec amet ultricies lorem.</p>
                                <p>All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary.Iipsum dolor sit amet consectetur adipiscing elitllus blandit massa enim.</p>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-lg-8">
                            <div class="carousel_slider owl-carousel owl-theme" data-margin="20" data-dots="false" data-loop="true" data-nav="true" data-autoplay="true" data-items="1">
                                <div class="item">
                                    <img src="<?php echo base_url() ?>frontend_assets/images/portfolio_img1.jpg" alt="portfolio_img1"/>
                                </div>
                                <div class="item">
                                    <img src="<?php echo base_url() ?>frontend_assets/images/portfolio_img2.jpg" alt="portfolio_img2"/>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4">
                            <ul class="list_none portfolio_info_box">
                                <li><span class="text-uppercase">CLIENT</span>Martyn Vorm</li>
                                <li><span class="text-uppercase">Date</span>Aprile 2018</li>
                                <li><span class="text-uppercase">Category</span>Design, Branding</li>
                                <li><span class="text-uppercase">PROJECT link</span>www.sitename.com</li>
                                <li><span class="text-uppercase">SHARE </span>
                                    <ul class="list_none social_icons border_social rounded_social">
                                        <li><a href="#"><i class="ion-social-facebook"></i></a></li>
                                        <li><a href="#"><i class="ion-social-twitter"></i></a></li>
                                        <li><a href="#"><i class="ion-social-googleplus"></i></a></li>
                                        <li><a href="#"><i class="ion-social-instagram-outline"></i></a></li>
                                        <li><a href="#"><i class="ion-social-pinterest"></i></a></li>
                                    </ul>
                                </li>
                            </ul>
                        </div>
                    </div>
            	</div>
            </div>
        </div>
    </div>
	
	<br>
	<hr>
	<br>

	<div class="container">
		<div class="row justify-content-center mt-5 pb-3">
        	<div class="col-xl-6 col-lg-7 col-md-9 text-center text-lg-left">
            	<div class="heading_s1">
                	<h2>Program Name</h2>
                </div>
            </div>
			
			<div class="col-xl-6 col-lg-7 col-md-9 text-center text-lg-right">
            	<div class="heading_s1">
                	<h2> <span>Date :</span>  10.03.2024</h2>
                </div>
            </div>
        </div>
		
        <div class="row">
            <div class="col-md-12">
            	
                <ul class="grid_container gutter_medium work_col3 portfolio_gallery portfolio_style1 masonry">
                	
                    <!-- START PORTFOLIO ITEM -->
                    <?php  
                      if($servs!==null) foreach($servs as $serv){?> 
					<li class="grid_item">
                        <div class="portfolio_item">
                            <a href="#" class="image_link">
                                <img src="<?php echo base_url() ?>public/uploads/service/<?php echo $serv['pro_image'];?>" alt="image">
                            </a>
                                <div class="portfolio_content">
                                    <div class="link_container">
                                        <a href="<?php echo base_url() ?>public/uploads/service/<?php echo $serv['pro_image'];?>" class="image_popup"><i class="ion-image"></i></a>
                                    </div>
                              </div>
                        </div>
                    </li>
					
				    <!-- END PORTFOLIO ITEM -->
                  <?php  }
                  else {
                    echo "<tr><td colspan='4'></td></tr>";
                }?>
                </ul>
            </div>
        </div>
    </div>
    <div class="portfolio_modal modal fade" id="pr_modal">
    	<div class="modal-dialog modal-xl modal-dialog-centered">	
        	<div class="modal-content">
            	<div class="modal-body">
                	<button type="button" class="close" data-dismiss="modal" aria-label="Close">
                      <span aria-hidden="true">×</span>
                    </button>
                    <div class="row">
                        <div class="col-12">
                            <div class="pf_content">	
                                <div class="heading_s1">
                                    <h2>Portfolio Title</h2>
                                </div>
                                <p>Nam eget neque pellentesque efficitur neque at, ornare orci. Vestibulum ligula orci volutpat id aliquet eget, consectetur eget ante. Duis pharetra for nec rhoncus felis sagittis nec amet ultricies lorem.</p>
                                <p>All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary.Iipsum dolor sit amet consectetur adipiscing elitllus blandit massa enim.</p>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-lg-8">
                            <div class="carousel_slider owl-carousel owl-theme" data-margin="20" data-dots="false" data-loop="true" data-nav="true" data-autoplay="true" data-items="1">
                                <div class="item">
                                    <img src="assets/images/portfolio_img1.jpg" alt="portfolio_img1"/>
                                </div>
                                <div class="item">
                                    <img src="assets/images/portfolio_img2.jpg" alt="portfolio_img2"/>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4">
                            <ul class="list_none portfolio_info_box">
                                <li><span class="text-uppercase">CLIENT</span>Martyn Vorm</li>
                                <li><span class="text-uppercase">Date</span>Aprile 2018</li>
                                <li><span class="text-uppercase">Category</span>Design, Branding</li>
                                <li><span class="text-uppercase">PROJECT link</span>www.sitename.com</li>
                                <li><span class="text-uppercase">SHARE </span>
                                    <ul class="list_none social_icons border_social rounded_social">
                                        <li><a href="#"><i class="ion-social-facebook"></i></a></li>
                                        <li><a href="#"><i class="ion-social-twitter"></i></a></li>
                                        <li><a href="#"><i class="ion-social-googleplus"></i></a></li>
                                        <li><a href="#"><i class="ion-social-instagram-outline"></i></a></li>
                                        <li><a href="#"><i class="ion-social-pinterest"></i></a></li>
                                    </ul>
                                </li>
                            </ul>
                        </div>
                    </div>
            	</div>
            </div>
        </div>
    </div>
	<br>
<br>

	<hr>
</div>

	
<!-- END WORK EXPERIENCES -->

<!-- START FOOTER SECTION --> 
<?php echo view('includes/frontend_footer'); ?>