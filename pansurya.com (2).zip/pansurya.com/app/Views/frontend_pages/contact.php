<?php echo view('includes/frontend_header'); ?>
<!-- START HEADER --> 

<!-- START SECTION BANNER -->
<div id="home_section" class="section banner_section banner_half_content bg_gray pb-0">
    <div class="banner_content_wrap">
        <div class="container"><!-- STRART CONTAINER -->
            <div class="row align-items-center justify-content-between">
                <div class="col-xl-6 col-md-7">
                    <div class="banner_content banner_center_content text-center text-md-left">
                        <h2 class="animation" data-animation="fadeInUp" data-animation-delay="0.02s">I'm PAN SURYA</h2>
                        <div id="typed-strings" class="d-none">
                            <b>CEO at Saradhi Consultancy Pvt Ltd</b>
                        </div>
                        <h4 class="animation" data-animation="fadeInUp" data-animation-delay="0.03s">I'm a <span id="typed-text" class="text_default"></span></h4>
                        <p class="animation" data-animation="fadeInUp" data-animation-delay="0.04s">Resourceful and visionary leader with comprehensive history in political affairs and development initiatives. </p>
                        <a href="#" class="btn btn-default rounded-0">Download CV</a>
                    </div>
                </div>
                <div class="col-xl-5 col-md-5">
                	<div class="banner_img animation" data-animation="fadeInUp" data-animation-delay="0.02s">
                    	<img src="<?php echo base_url() ?>frontend_assets/images/my_image.png" alt="my_image">
                    </div>
                </div>
            </div>
        </div><!-- END CONTAINER-->
    </div>
    <div class="shape_wrap">
        <div class="shape1">
        	<div class="animation1">
            	<img src="<?php echo base_url() ?>frontend_assets/images/shape1.png" alt="shape">
            </div>
        </div>
        <div class="shape2">
        	<div class="animation2">
            	<img src="<?php echo base_url() ?>frontend_assets/images/shape2.png" alt="shape">
            </div>
        </div>
        <div class="shape3">
        	<div class="animation5">
            	<img src="<?php echo base_url() ?>frontend_assets/images/shape3.png" alt="shape">
            </div>
        </div>
        <div class="shape4">
        	<div class="animation6">
            	<img src="<?php echo base_url() ?>frontend_assets/images/shape4.png" alt="shape">
            </div>
        </div>
        <div class="shape5">
        	<div class="animation5">
            	<img src="<?php echo base_url() ?>frontend_assets/images/shape5.png" alt="shape">
            </div>
        </div>
        <div class="shape6">
        	<div class="animation1">
            	<img src="<?php echo base_url() ?>frontend_assets/images/shape6.png" alt="shape">
            </div>
        </div>
        <div class="shape7">
        	<div class="animation5">
            	<img src="<?php echo base_url() ?>frontend_assets/images/shape7.png" alt="shape">
            </div>
        </div>
        <div class="shape8">
        	<div class="animation2">
            	<img src="<?php echo base_url() ?>frontend_assets/images/shape8.png" alt="shape">
            </div>
        </div>
    </div>
</div>
<!-- END SECTION BANNER --> 

<!-- START SECTION ABOUT US -->
<div id="about" class="section small_pb bg_redon">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-lg-4 col-md-12 animation" data-animation="fadeInUp" data-animation-delay="0.1s">
                <div class="about_img2">
                    <img src="<?php echo base_url() ?>frontend_assets/images/about_img2.jpg" alt="about_img">
                </div>
            </div>
            <div class="col-lg-8 animation" data-animation="fadeInUp" data-animation-delay="0.2s">
                <div class="heading_s1"> 
                  <h2>About Me</h2>
                </div>
                <p>Resourceful and visionary leader with comprehensive history in political affairs and development initiatives. </p>
                <p>Experienced at managing budgets, presiding over council meetings, handling local emergencies tand administering public events. Adept at assessing community issues and managing budgets. Committed to supporting public interest and promoting peace and prosperity.</p>
                <ul class="profile_info list_none mb-4 pt-2 border-bottom">
                    <li>
                        <span class="title">Date of birth:</span>
                        <p>20 August 1990</p>
                    </li>
                    <li>
                        <span class="title">Phone No:</span>
                        <p>+91 95199 63199</p>
                    </li>
                    <li>
                        <span class="title">Email:</span>
                        <a href="mailto:info@pansurya.com">info@pansurya.com</a>
                    </li>
                    <li>
                        <span class="title">Address:</span>
                        <p> Visakhapatnam </p>
                    </li>
                    <li>
                        <span class="title">Website:</span>
                        <p> www.pansurya.com </p>
                    </li>
<!--
                    <li>
                        <span class="title">Freelance:</span>
                        <p>Available</p>
                    </li>
-->
                </ul>
<!--                <a href="#" class="btn btn-default rounded-0">Download CV</a>-->
            </div>
        </div>
    </div>
</div>
<!-- END SECTION ABOUT US -->

<!-- START SECTION SKILL -->
<div class="section small_pt pb_70 ">
	<div class="container">
    	<div class="row justify-content-center">
        	<div class="col-xl-6 col-lg-7 col-md-9 text-center">
            	<div class="heading_s1 text-center">
                	<h2>My Skills</h2>
                </div>
				<br>
<br>

<!--                 <p class="leads">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus blandit massa Nullam id varius nunc id varius nunc.</p>-->
            </div>
        </div>
    	<div class="row">
            <div class="col-md-3 col-6">
                <div class="circular_bar text-center">
                    <div class="circular_bar_chart" data-percent="76" data-bar-color="#FF324D" data-track-color="#eee" data-size="170" data-track-width="5" data-line-width="5">
                        <span class="percent"></span>
                    </div>
                    <div class="circular_bar_text">
                    	<h5>Oral & Written Communication Skills</h5>
                    </div>
                </div>
            </div>
            <div class="col-md-3 col-6">
                <div class="circular_bar text-center">
                    <div class="circular_bar_chart" data-percent="70" data-bar-color="#FF324D" data-track-color="#eee" data-size="170" data-track-width="5" data-line-width="5">
                        <span class="percent"></span>
                    </div>
                    <div class="circular_bar_text">
                    	<h5>Teamwork</h5>
                    </div>
                </div>
            </div>
            <div class="col-md-3 col-6">
                <div class="circular_bar text-center">
                    <div class="circular_bar_chart" data-percent="86" data-bar-color="#FF324D" data-track-color="#eee" data-size="170" data-track-width="5" data-line-width="5">
                        <span class="percent"></span>
                    </div>
                    <div class="circular_bar_text">
                    	<h5>Decision Making</h5>
                    </div>
                </div>
            </div>
            <div class="col-md-3 col-6">
                <div class="circular_bar text-center">
                    <div class="circular_bar_chart" data-percent="69" data-bar-color="#FF324D" data-track-color="#eee" data-size="170" data-track-width="5" data-line-width="5">
                        <span class="percent"></span>
                    </div>
                    <div class="circular_bar_text">
                    	<h5>Stress Management</h5>
                    </div>
                </div>
            </div>
            <div class="col-md-3 col-6">
                <div class="circular_bar text-center">
                    <div class="circular_bar_chart" data-percent="70" data-bar-color="#FF324D" data-track-color="#eee" data-size="170" data-track-width="5" data-line-width="5">
                        <span class="percent"></span>
                    </div>
                    <div class="circular_bar_text">
                    	<h5>Analytical Skills</h5>
                    </div>
                </div>
            </div>
            <div class="col-md-3 col-6">
                <div class="circular_bar text-center">
                    <div class="circular_bar_chart" data-percent="86" data-bar-color="#FF324D" data-track-color="#eee" data-size="170" data-track-width="5" data-line-width="5">
                        <span class="percent"></span>
                    </div>
                    <div class="circular_bar_text">
                    	<h5>Strategic Thinking</h5>
                    </div>
                </div>
            </div>
            <div class="col-md-3 col-6">
                <div class="circular_bar text-center">
                    <div class="circular_bar_chart" data-percent="69" data-bar-color="#FF324D" data-track-color="#eee" data-size="170" data-track-width="5" data-line-width="5">
                        <span class="percent"></span>
                    </div>
                    <div class="circular_bar_text">
                    	<h5>Leadership Skills</h5>
                    </div>
                </div>
            </div>
            <div class="col-md-3 col-6">
                <div class="circular_bar text-center">
                    <div class="circular_bar_chart" data-percent="86" data-bar-color="#FF324D" data-track-color="#eee" data-size="170" data-track-width="5" data-line-width="5">
                        <span class="percent"></span>
                    </div>
                    <div class="circular_bar_text">
                    	<h5>Public Speaking</h5>
                    </div>
                </div>
            </div>
            <div class="col-md-3 col-6">
                <div class="circular_bar text-center">
                    <div class="circular_bar_chart" data-percent="69" data-bar-color="#FF324D" data-track-color="#eee" data-size="170" data-track-width="5" data-line-width="5">
                        <span class="percent"></span>
                    </div>
                    <div class="circular_bar_text">
                    	<h5>Cultural Awareness...etc</h5>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- START SECTION SKILL -->


<!-- START SECTION SERVICES -->
<div id="expertise" class="section pb_70 bg_redon">
	<div class="container">
    	<div class="row justify-content-center">
        	<div class="col-xl-6 col-lg-7 col-md-9 text-center">
            	<div class="heading_s1 text-center">
                	<h2>Expertise</h2>
                </div>
<!--                 <p class="leads">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus blandit massa Nullam id varius nunc id varius nunc.</p>-->
				<br>

            </div>
        </div>
        <div class="row">
        	<div class="col-lg-3 col-sm-6 text-center">
            	<div class="icon_box icon_box_style_2">
                    <div class="box_icon">	
                        <i class="ti-angle-double-down"></i>
                    </div>
                    <div class="icon_box_content">
                        <h5> Project Management </h5>
                    </div>
                </div>
            </div>
        	<div class="col-lg-3 col-sm-6 text-center">
            	<div class="icon_box icon_box_style_2">
                    <div class="box_icon">	
                        <i class="ti-angle-double-down"></i>
                    </div>
                    <div class="icon_box_content">
                        <h5> Budgeting </h5>
                    </div>
                </div>
            </div>
        	<div class="col-lg-3 col-sm-6 text-center">
            	<div class="icon_box icon_box_style_2">
                    <div class="box_icon">	
                        <i class="ti-angle-double-down"></i>
                    </div>
                    <div class="icon_box_content">
                        <h5> Continuous Process </h5>
                    </div>
                </div>
            </div>
        	<div class="col-lg-3 col-sm-6 text-center">
            	<div class="icon_box icon_box_style_2">
                    <div class="box_icon">	
                        <i class="ti-angle-double-down"></i>
                    </div>
                    <div class="icon_box_content">
                        <h5> Community Development </h5>
                    </div>
                </div>
            </div>
        	<div class="col-lg-3 col-sm-6 text-center">
            	<div class="icon_box icon_box_style_2">
                    <div class="box_icon">	
                        <i class="ti-angle-double-down"></i>
                    </div>
                    <div class="icon_box_content">
                        <h5> Relationship Building </h5>
                    </div>
                </div>
            </div>
        	<div class="col-lg-3 col-sm-6 text-center">
            	<div class="icon_box icon_box_style_2">
                    <div class="box_icon">	
                        <i class="ti-angle-double-down"></i>
                    </div>
                    <div class="icon_box_content">
                        <h5> Problem Solving </h5>
                    </div>
                </div>
            </div>
        	<div class="col-lg-3 col-sm-6 text-center">
            	<div class="icon_box icon_box_style_2">
                    <div class="box_icon">	
                        <i class="ti-angle-double-down"></i>
                    </div>
                    <div class="icon_box_content">
                        <h5> Grants Management </h5>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- END SECTION SERVICES -->
	


<!-- START SECTION TESTIMONIAL -->
<div id="home_section" class="section banner_section banner_half_content bg_gray pb-0">
    <div class="banner_content_wrap">
        <div class="container"><!-- STRART CONTAINER -->
            <div class="row align-items-center justify-content-between">
                <div class="col-xl-6 col-md-7">
                    <div class="banner_content banner_center_content text-center text-md-left">
                        <h2 class="animation" data-animation="fadeInUp" data-animation-delay="0.02s">I'm PAN SURYA</h2>
                        <div id="typed-strings" class="d-none">
                            <b>CEO at Saradhi Consultancy Pvt Ltd</b>
                        </div>
                        <h4 class="animation" data-animation="fadeInUp" data-animation-delay="0.03s">I'm a <span id="typed-text" class="text_default"></span></h4>
                        <p class="animation" data-animation="fadeInUp" data-animation-delay="0.04s">Resourceful and visionary leader with comprehensive history in political affairs and development initiatives. </p>
                        <a href="#" class="btn btn-default rounded-0">Download CV</a>
                    </div>
                </div>
                <div class="col-xl-5 col-md-5">
                	<div class="banner_img animation" data-animation="fadeInUp" data-animation-delay="0.02s">
                    	<img src="assets/images/my_image.png" alt="my_image">
                    </div>
                </div>
            </div>
        </div><!-- END CONTAINER-->
    </div>
    <div class="shape_wrap">
        <div class="shape1">
        	<div class="animation1">
            	<img src="assets/images/shape1.png" alt="shape">
            </div>
        </div>
        <div class="shape2">
        	<div class="animation2">
            	<img src="assets/images/shape2.png" alt="shape">
            </div>
        </div>
        <div class="shape3">
        	<div class="animation5">
            	<img src="assets/images/shape3.png" alt="shape">
            </div>
        </div>
        <div class="shape4">
        	<div class="animation6">
            	<img src="assets/images/shape4.png" alt="shape">
            </div>
        </div>
        <div class="shape5">
        	<div class="animation5">
            	<img src="assets/images/shape5.png" alt="shape">
            </div>
        </div>
        <div class="shape6">
        	<div class="animation1">
            	<img src="assets/images/shape6.png" alt="shape">
            </div>
        </div>
        <div class="shape7">
        	<div class="animation5">
            	<img src="assets/images/shape7.png" alt="shape">
            </div>
        </div>
        <div class="shape8">
        	<div class="animation2">
            	<img src="assets/images/shape8.png" alt="shape">
            </div>
        </div>
    </div>
</div>
<!-- END SECTION TESTIMONIAL -->


	<!-- START WORK EXPERIENCES -->
<div id="education" class="section pb_70 bg_redon ">
	<div class="container">
    	<div class="row justify-content-center">
        	<div class="col-xl-6 col-lg-7 col-md-9 text-center">
            	<div class="heading_s1">
                	<h2>Education</h2>
                </div>
<!--                <p class="leads">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus blandit massa Nullam id varius nunc id varius nunc.</p>-->
            </div>
        </div>
        <div class="row">
        	<div class="col-md-12">
                <div class="tab-content">
                    <div class="tab-pane fade show active" id="Education" role="tabpanel">
                    	<div class="row">
                            <div class="col-lg-4 col-sm-6">
                                <div class="icon_box icon_box_style_1 radius_box_10">
                                    <div class="icon_box_content">
                                        <h4>MBA</h4>
                                        <p><span class="text_default">2016</span> Andhra University.</p>
                                        <hr>
                                        <p>There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form</p>
                                    </div>
                                </div>
                            </div>
<!--
                            <div class="col-lg-4 col-sm-6">
                                <div class="icon_box icon_box_style_1 radius_box_10">
                                    <div class="icon_box_content">
                                        <h4>Google company</h4>
                                        <p><span class="text_default">2007-2010</span> Google Inc.</p>
                                        <hr>
                                        <p>There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form</p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-4 col-sm-6">
                                <div class="icon_box icon_box_style_1 radius_box_10">
                                    <div class="icon_box_content">
                                        <h4>Marketing Manager</h4>
                                        <p><span class="text_default">2010-2013</span> Google Inc.</p>
                                        <hr>
                                        <p>There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form</p>
                                    </div>
                                </div>
                            </div>
-->
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- END WORK EXPERIENCES -->

	<!-- START WORK EXPERIENCES -->
<div id="experience" class="section pb_70">
	<div class="container">
        <div class="row">
        	
            <div class="col-md-12">
            	<div class="heading_s1">
            		<h5>Experience</h5>
                </div>
                <div class="small_divider clearfix"></div>
                <div class="timeline">
                    <div class="timeline_box">
                    	<div class="timeline_icon">
                        	<i class="fas fa-briefcase"></i>
                        </div>
                        <div class="timeline_content">
                            <p><span class="text_default">May 2016 - Dec 2018</span> (Telugu Daily Paper)</p>
                            <h4>Editor - AKSHARA NIJAM </h4>
                            <hr>
                            <p>Desk Incharge for Vizag, Vizianagaram and Srikakulam areas for finalising articles and trained for Mass communication field and also for editorial page creations very passionate about the creative field.</p>
                        </div>
                    </div>
                    <div class="timeline_box">
                    	<div class="timeline_icon">
                        	<i class="fas fa-briefcase"></i>
                        </div>
                        <div class="timeline_content">
                            <p><span class="text_default">Jan 2019 - May 2020</span> ING VYSYA BANK </p>
                            <h4>Branch Operational Manager</h4>
                            <hr>
                            <p>Opening a healthy accounts, marketing management for the team and financial assistance management training for clients and account holders to maintain their accounts. IRDA insurance plans mapping.</p>
                        </div>
                    </div>
                    <div class="timeline_box">
                    	<div class="timeline_icon">
                        	<i class="fas fa-briefcase"></i>
                        </div>
                        <div class="timeline_content">
                            <p><span class="text_default">Jun 2020</span>Raghava Charitable Trust  </p>
                            <h4>Founder and Chairman</h4>
                            <hr>
                            <p>He personally Motivativated and skill development training classes for approx 1500+ Youth and it helps them to earn. He helped 1200+ farmers financially and also to get better yeilding from the background.</p>
							<a href="https://rctism.com/" target="_blank" class="btn btn-default rounded-0">www.rctism.com</a>
                        </div>
                    </div>
                    <div class="timeline_box">
                    	<div class="timeline_icon">
                        	<i class="fas fa-briefcase"></i>
                        </div>
                        <div class="timeline_content">
                            <p><span class="text_default">July 2020</span>Mahati Step Private Limited  </p>
                            <h4>Founder and Chairman</h4>
                            <hr>
                            <p>He personally Motivativated and skill development training classes for approx 1500+ Youth and it helps them to earn. He helped 1200+ farmers financially and also to get better yeilding from the background.</p>
							<a href="https://mahathistep.com/" target="_blank" class="btn btn-default rounded-0">www.mahatistep.com</a>
                        </div>
                    </div>
                    <div class="timeline_box">
                    	<div class="timeline_icon">
                        	<i class="fas fa-briefcase"></i>
                        </div>
                        <div class="timeline_content">
                            <p><span class="text_default">April 2022</span>Maasaradhi </p>
                            <h4>CEO - Saradhi Consultancy Pvt Ltd</h4>
                            <hr>
                            <p>Helping hands are better than prayings lips. Many people are helping who are in need. His thoughts into NGO organisations also need a assistance to maintain NGO in proper way & helped 2400+ organisations across PAN India.</p>
							<a href="https://maasaradhi.com/" target="_blank" class="btn btn-default rounded-0">www.maasaradhi.com</a>
                        </div>
                    </div>
                    
                </div>
            </div>
        </div>
    </div>
</div>
<!-- END WORK EXPERIENCES -->


<!-- START SECTION CONTACT -->
<div id="contact" class="section bg_redon">
	<div class="container">
    	<div class="row">
        	<div class="col-lg-4">
            	<div class="heading_s1">
                	<h2>Get In Touch</h2>
                </div>
                <div class="contact_info_wrap">
                    <div class="contact_wrap contact_style1">
                        <div class="contact_icon">
                            <i class="ti-location-pin"></i>
                        </div>
                        <div class="contact_text">
                            <span>Address</span>
                            <p>Visakhapatnam </p>
                        </div>
                    </div>
                    <div class="contact_wrap contact_style1">
                        <div class="contact_icon">
                            <i class="ti-mobile"></i>
                        </div>
                        <div class="contact_text">
                            <span>Phone</span>
                            <p>+91 95199 63199</p>
                        </div>
                    </div>
                    <div class="contact_wrap contact_style1">
                        <div class="contact_icon">
                            <i class="ti-email"></i>
                        </div>
                        <div class="contact_text">
                            <span>Email Address</span>
                            <a href="mailto:info@pansurya.com">info@pansurya.com</a>
                        </div>
                    </div>
                </div>
            </div>
        	<div class="col-lg-8">
            <div class="field_form contact_form">
                    <form method="post" action="<?php echo base_url();?>public/savecontact" name="">
                        <div class="row">
                            <div class="form-group col-md-12">
                                <input required="" placeholder="Enter Name *" id="first-name" class="form-control rounded-0" name="first-name" type="text"  value="<?php echo (isset($record['first-name']) ? $record['first-name']: ""); ?>">
                             </div>
                            <div class="form-group col-md-6">
                                <input required="" placeholder="Enter Email *" id="email" class="form-control rounded-0" name="email" type="email"  value="<?php echo (isset($record['email']) ? $record['email']: ""); ?>">
                            </div>
                            <div class="form-group col-md-6">
                                <input required="" placeholder="Enter Phone No. *" id="phone" class="form-control rounded-0" name="phone"  value="<?php echo (isset($record['phone']) ? $record['phone']: ""); ?>">
                            </div>
                            <div class="form-group col-md-12">
                                <textarea required="" placeholder="Message *" id="description" name="description" class="form-control rounded-0" name="message" rows="4" value="<?php echo (isset($record['description']) ? $record['description']: ""); ?>"></textarea>
                            </div>
                            <div class="col-md-12">
                            <button type="submit" class="btn btn-default rounded-0 float-right">Submit</button>
                            <div class="col-md-12">
                                <div id="alert-msg" class="alert-msg text-center"></div>
                            </div>
                        </div>
            </div>
        </div>
    </div>
</div>
<!-- START SECTION CONTACT -->

<!-- START FOOTER SECTION --> 
<?php echo view('includes/frontend_footer'); ?>
