

<?php  $this->session =session();
?> 


<?php echo view('includes/header');?>
<!--**********************************
    Nav header end
***********************************-->		      
<!--**********************************
    Header start
***********************************-->
<?php echo view('includes/top_right_menu');?>
<!--**********************************
    Header end ti-comment-alt
***********************************-->        <!--**********************************
    Sidebar start
***********************************-->
<?php echo view('includes/leftmenu');?>
<!--**********************************
    Sidebar end
***********************************-->        <!--**********************************
    Content body start
***********************************-->
<div class="content-body" style="min-height: 788px;">
	<div class="container-fluid">
		<div class="page-titles">
			<ol class="breadcrumb">
				<li class="breadcrumb-item"><a href="javascript:void(0)">App</a></li>
				<li class="breadcrumb-item active"><a href="javascript:void(0)">Profile</a></li>
			</ol>
        </div>
		<!-- row -->
		<div class="row">
			<div class="col-lg-12">
				<div class="profile card card-body px-3 pt-3 pb-0">
					<div class="profile-head">
						<div class="photo-content">
							<div class="cover-photo rounded"></div>
						</div>
						<div class="profile-info">
							<div class="profile-photo">
								<a class="test-popup-link" href="public/assets/images/1.jpg"><img src="public/assets/images/profile/5.jpg" class="img-fluid rounded-circle" alt=""></a>
							</div>
							<div class="profile-details">
								<div class="profile-name px-3 pt-2">
									<h4 class="text-primary mb-0"><?php echo $this->session->get('name');?></h4>
<!--									<p>UX / UI Designer</p>-->
								</div>
								<div class="profile-email px-2 pt-2">
<!--									<h4 class="text-muted mb-0">info@example.com</h4>-->
								</div>
								<!-- <div class="dropdown ms-auto">
									<a href="#" class="btn btn-primary light sharp" data-bs-toggle="dropdown" aria-expanded="true"><svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="18px" height="18px" viewBox="0 0 24 24" version="1.1"><g stroke="none" stroke-width="1" fill="none" fill-rule="evenodd"><rect x="0" y="0" width="24" height="24"></rect><circle fill="#000000" cx="5" cy="12" r="2"></circle><circle fill="#000000" cx="12" cy="12" r="2"></circle><circle fill="#000000" cx="19" cy="12" r="2"></circle></g></svg></a>
									<ul class="dropdown-menu dropdown-menu-end">
										<li class="dropdown-item"><a href=""><a href="edit_profile.html"><i class="fa fa-user-circle text-primary me-2"></i> Edit profile</li></a>
										<li class="dropdown-item">
											<a href="change_password.html"><i class="fa fa-key text-primary me-2"></i> Change Password</a>
										</li>
										<li class="dropdown-item"><a href="page_login.html"><i class="fa fa-sign-out text-primary me-2"></i> logout</a></li>
										
									</ul>
								</div> -->
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<div class="card">
					<div class="row">
						<div class="col-md-12">
					    <div class="card-body">
						<ul>
						     <li> <strong>Name</strong> :<?php echo $this->session->get('name');?> </li>
							<li> <strong>Contact No.</strong> :<?php echo $this->session->get('mobile');?></li>
							<li> <strong>Email ID</strong> :<?php echo $this->session->get('email');?> </li>
							<!-- <li> <strong>Aadhar No.</strong> :<?php //echo $this->session->get('name');?>  </li>
							 -->
							<hr>

							
							
						</ul>
					</div>
							
							
							
						</div>
						
						
						
					</div>
					
				</div>
		<br>


	</div>
</div>
		

<!--**********************************
    Content body end
***********************************-->
        <!--**********************************
    Footer start
***********************************-->
<?php echo view('includes/footer');?>