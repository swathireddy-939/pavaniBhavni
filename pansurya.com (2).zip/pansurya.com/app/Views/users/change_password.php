<?php echo view('includes/header');?>
<!--**********************************
    Nav header end
***********************************-->		      
<!--**********************************
    Header start
***********************************-->
<?php echo view('includes/top_right_menu');?>
<!--**********************************
    Header end ti-comment-alt
***********************************-->        <!--**********************************
    Sidebar start
***********************************-->
<?php echo view('includes/leftmenu');?>
<!--**********************************
    Sidebar end
***********************************-->        <!--**********************************
    Content body start
***********************************-->
<div class="content-body" style="min-height: 788px;">
	<div class="container-fluid">
		<div class="page-titles">
			<ol class="breadcrumb">
				<li class="breadcrumb-item"><a href="javascript:void(0)">Dashboard</a></li>
				<li class="breadcrumb-item "><a href="javascript:void(0)">Profile</a></li>
				<li class="breadcrumb-item active"><a href="javascript:void(0)">Change Password</a></li>
			</ol>
        </div>
		<!-- row -->
		<div class="row">
			<div class="col-lg-12">
				<div class="profile card card-body px-3 pt-3 pb-0">
					<div class="profile-head">
						<div class="photo-content">
							<div class="cover-photo rounded"></div>
						</div>
						<div class="profile-info">
							<div class="profile-photo">
								<a class="test-popup-link" href="public/assets/images/1.jpg"><img src="public/assets/images/profile/5.jpg" class="img-fluid rounded-circle" alt=""></a>
							</div>
							<div class="profile-details">
								<div class="profile-name px-3 pt-2">
									<h4 class="text-primary mb-0">Mitchell C. Shay</h4>
									<p>UX / UI Designer</p>
								</div>
<!--
								<div class="profile-email px-2 pt-2">
									<h4 class="text-muted mb-0">info@example.com</h4>
								</div>
-->
								<div class="dropdown ms-auto">
									<a href="#" class="btn btn-primary light sharp" data-bs-toggle="dropdown" aria-expanded="true"><svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="18px" height="18px" viewBox="0 0 24 24" version="1.1"><g stroke="none" stroke-width="1" fill="none" fill-rule="evenodd"><rect x="0" y="0" width="24" height="24"></rect><circle fill="#000000" cx="5" cy="12" r="2"></circle><circle fill="#000000" cx="12" cy="12" r="2"></circle><circle fill="#000000" cx="19" cy="12" r="2"></circle></g></svg></a>
									<ul class="dropdown-menu dropdown-menu-end">
										<li class="dropdown-item"><i class="fa fa-user-circle text-primary me-2"></i> <a href="app_profile.html">View profile</a></li>
<!--
										<li class="dropdown-item"><a href="changepawword.html">
											<i class="fa fa-key text-primary me-2"></i> Change Password
											</a></li>
-->
										<li class="dropdown-item"><a href="page_login.html"><i class="fa fa-sign-out text-primary me-2"></i> logout</a></li>
										
									</ul>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<div class="row">
			<div class="col-xl-6 offset-lg-3">
				<div class="card">
					<div class="card-body">
						<div class="profile-tab">
							<div class="custom-tab-1">
								<div class="tab-content">
									
									<div class="basic-form">
                            <form>

                                <div class="row">
									<div class="mb-12 col-md-12 mb-3">
                                        <label class="form-label">Old Password</label>
                                        <input type="text" class="form-control" placeholder="*********">
                                    </div>
									<div class="mb-12 col-md-12 mb-3">
                                        <label class="form-label">New Password</label>
                                        <input type="text" class="form-control" placeholder="*********">
                                    </div>
									<div class="mb-12 col-md-12 mb-3">
                                        <label class="form-label">Confirm Password</label>
                                        <input type="text" class="form-control" placeholder="*********">
                                    </div>
                                </div>
								
								<a href="page_login.html" class="btn btn-primary ms-2"><i class="fas fa-save px-2"></i>Submit</a>
								
                            </form>
                        </div>
									
								</div>
							</div>
							<!-- Modal -->
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<!--**********************************
    Content body end
***********************************-->
        <!--**********************************
    Footer start
***********************************-->
<?php echo view('includes/footer');?>