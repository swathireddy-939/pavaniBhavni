<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta charset="utf-8">
    <meta name="keywords" content="">
	<meta name="author" content="">
	<meta name="robots" content="">
	<meta name="format-detection" content="telephone=no">
    <title> :: Church Plenary :: </title>
    <!-- Favicon icon -->
	
	<link rel="icon" type="image/png" sizes="16x16" href="public/assets/images/favicon.png">	
		 <link href="public/assets/vendor/jqvmap/css/jqvmap.min.css" rel="stylesheet" type="text/css">	
		 <link href="public/assets/vendor/chartist/css/chartist.min.css" rel="stylesheet" type="text/css">	
		 <link href="public/assets/vendor/owl-carousel/owl.carousel.css" rel="stylesheet" type="text/css">	
		 <link href="public/assets/vendor/bootstrap-select/dist/css/bootstrap-select.min.css" rel="stylesheet" type="text/css">	
		 <link href="public/assets/css/style.css" rel="stylesheet" type="text/css">	
</head>
<body class="h-100">
    <div class="authincation h-100">
        <div class="container h-100">
            <div class="row justify-content-center h-100 align-items-center">
                <div class="col-md-6 mt-lg-5 pt-lg-5">
                    <div class="authincation-content">
                        <div class="row no-gutters">
                            <div class="col-xl-12">
                                <div class="auth-form">
                                    <div class="text-center mb-3">
                                        <a href="index.htm"><img src="public/assets/images/logo-full.png" alt=""></a>
                                    </div>
                                    <h4 class="text-center mb-4 text-white">Forgot Password</h4>
                                    <form action="">
                                        <div class="form-group">
                                            <label class="text-white"><strong>Email</strong></label>
                                            <input type="email" class="form-control" value="hello@example.com">
                                        </div>
                                        <div class="text-center">
                                            <a href="change_password.html" type="submit" class="btn bg-white text-primary btn-block">SUBMIT</a>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

	
			<script src="public/assets/vendor/global/global.min.js"></script>
			<script src="public/assets/vendor/bootstrap-select/dist/js/bootstrap-select.min.js"></script>
		
			<script src="public/assets/vendor/chart.js/Chart.bundle.min.js"></script>
			<script src="public/assets/vendor/peity/jquery.peity.min.js"></script>
			<script src="public/assets/vendor/apexchart/apexchart.js"></script>
			<script src="public/assets/vendor/owl-carousel/owl.carousel.js"></script>
			<script src="public/assets/js/dashboard/dashboard-1.js"></script>
		
			<script src="public/assets/js/custom.min.js"></script>
			<script src="public/assets/js/deznav-init.js"></script>
			<script src="public/assets/js/demo.js"></script>

	
    <!--**********************************
        Main wrapper end
    ***********************************-->
</body>
</html>