<?php if(session()->getFlashdata('msg')):?>
              <?= session()->getFlashdata('msg'); ?> 
                <?php endif;?>