<footer class="footer_dark bg_black bottom_footer">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-md-12 order-md-1">   
                <p class="copyright m-0 text-center fa-1x">© 2024 All Rights Reserved By Pansurya.</p>
            </div>
        </div>
    </div>
</footer>
<!-- END FOOTER SECTION --> 
	
	<div class="fixed-button">
		<a href="<?php echo base_url() ?>public/follow" >
			<img src="<?php echo base_url() ?>frontend_assets/images/we_stand.png" alt="">
		</a>
	</div>
	
	<!-- The Modal -->
  

<a href="#" class="scrollup" style="display: none;"><i class="ion-ios-arrow-up"></i></a> 

<!-- Latest jQuery --> 
<script src="<?php echo base_url() ?>frontend_assets/js/jquery-1.12.4.min.js"></script> 
<!-- Latest compiled and minified Bootstrap --> 
<script src="<?php echo base_url() ?>frontend_assets/bootstrap/js/bootstrap.min.js"></script> 
<!-- owl-carousel min js  --> 
<script src="<?php echo base_url() ?>frontend_assets/owlcarousel/js/owl.carousel.min.js"></script> 
<!-- magnific-popup min js  --> 
<script src="<?php echo base_url() ?>frontend_assets/js/magnific-popup.min.js"></script> 
<!-- waypoints min js  --> 
<script src="<?php echo base_url() ?>frontend_assets/js/waypoints.min.js"></script> 
<!-- countdown js  --> 
<script src="<?php echo base_url() ?>frontend_assets/js/jquery.countTo.js"></script> 
<!-- jquery.counterup.min js --> 
<script src="<?php echo base_url() ?>frontend_assets/js/jquery.counterup.min.js"></script>
<!-- imagesloaded js -->
<script src="<?php echo base_url() ?>frontend_assets/js/imagesloaded.pkgd.min.js"></script>
<!-- jquery.appear js  -->
<script src="<?php echo base_url() ?>frontend_assets/js/jquery.appear.js"></script>
<!-- isotope min js --> 
<script src="<?php echo base_url() ?>frontend_assets/js/isotope.min.js"></script>
<!-- typed.min js --> 
<script src="<?php echo base_url() ?>frontend_assets/js/typed.min.js"></script>
<!-- typed text js --> 
<script src="<?php echo base_url() ?>frontend_assets/js/typed-text.js"></script>
<!-- particles min js  -->
<script src="<?php echo base_url() ?>frontend_assets/js/particles.min.js"></script>
<!-- easypiechart js -->
<script src="<?php echo base_url() ?>frontend_assets/js/jquery.easypiechart.min.js"></script>
<!-- scripts js --> 
<script src="<?php echo base_url() ?>frontend_assets/js/scripts.js"></script>

</body>
</htm