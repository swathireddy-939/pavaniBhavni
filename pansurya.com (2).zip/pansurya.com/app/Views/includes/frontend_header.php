<!DOCTYPE html>
<html lang="en">
<head>
<!-- Meta -->
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">

<!-- SITE TITLE -->
<title> :: PAN SURYA :: </title>
<!-- Favicon Icon -->
<link rel="shortcut icon" type="image/x-icon" href="<?php echo base_url() ?>frontend_assets/images/favicon.png">
<!-- Animation CSS -->
<link rel="stylesheet" href="<?php echo base_url() ?>frontend_assets/css/animate.css">	
<!-- Latest Bootstrap min CSS -->
<link rel="stylesheet" href="<?php echo base_url() ?>frontend_assets/bootstrap/css/bootstrap.min.css">
<!-- Google Font -->
<link href="../../css?family=Montserrat:100,100i,200,200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">
<link href="../../css-1?family=Roboto:100,100i,300,300i,400,400i,500,500i,700,700i,900,900i" rel="stylesheet">
<!-- Icon Font CSS -->
<link rel="stylesheet" href="<?php echo base_url() ?>frontend_assets/css/ionicons.min.css">
<link rel="stylesheet" href="<?php echo base_url() ?>frontend_assets/css/themify-icons.css">
<link rel="stylesheet" href="<?php echo base_url() ?>frontend_assets/css/linearicons.css">
<!-- FontAwesome CSS -->
<link rel="stylesheet" href="<?php echo base_url() ?>frontend_assets/css/all.min.css">
<!-- Flaticon Font CSS -->
<link rel="stylesheet" href="<?php echo base_url() ?>frontend_assets/css/flaticon.css">
<!--- owl carousel CSS-->
<link rel="stylesheet" href="<?php echo base_url() ?>frontend_assets/owlcarousel/css/owl.carousel.min.css">
<link rel="stylesheet" href="<?php echo base_url() ?>frontend_assets/owlcarousel/css/owl.theme.css">
<link rel="stylesheet" href="<?php echo base_url() ?>frontend_assets/owlcarousel/css/owl.theme.default.min.css">
<!-- Magnific Popup CSS -->
<link rel="stylesheet" href="<?php echo base_url() ?>frontend_assets/css/magnific-popup.css">
<!-- Style CSS -->
<link rel="stylesheet" href="<?php echo base_url() ?>frontend_assets/css/style.css">
<link rel="stylesheet" href="<?php echo base_url() ?>frontend_assets/css/responsive.css">
<link rel="stylesheet" id="layoutstyle" href="<?php echo base_url() ?>frontend_assets/color/theme-red.css">

</head>

<body data-spy="scroll" data-target=".navbar-nav" data-offset="110">

<!-- LOADER -->
<div id="preloader">
    <span class="spinner"></span>
    <div class="loader-section section-left"></div>
    <div class="loader-section section-right"></div>
</div>
<!-- END LOADER --> 

<!-- START HEADER -->
<header class="header_wrap fixed-top dark_skin hover_menu_style1 transparent-header">
  <div class="container">
    <nav class="navbar navbar-expand-lg"> 
    	<a class="navbar-brand page-scroll" href="index.html">
        	<img class="logo_light" src="<?php echo base_url() ?>frontend_assets/images/logo_white.png" alt="logo">
            <img class="logo_dark" src="<?php echo base_url() ?>frontend_assets/images/logo_dark.png" alt="logo">
        </a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation"> <span class="ion-android-menu"></span> </button>
      	<div class="collapse navbar-collapse justify-content-end" id="navbarSupportedContent">
            <ul class="navbar-nav">
                <li>
                    <a class="nav-link  page-scroll" href="<?php echo base_url() ?>public/">Home</a>
                </li>
                <li>
                    <a class="nav-link page-scroll" href="<?php echo base_url() ?>public/#about">About</a>
                </li>
                <li>
                    <a class="nav-link  page-scroll" href="<?php echo base_url() ?>public/service">Services</a>
                </li>
                <li>
                    <a class="nav-link page-scroll" href="<?php echo base_url() ?>public/#expertise">Expertise</a>
                </li>
               
                <li>
                    <a class="nav-link page-scroll" href="<?php echo base_url() ?>public/#education">Education</a>
                </li>
                <li>
                    <a class="nav-link page-scroll" href="<?php echo base_url() ?>public/#experience">Experience</a>
                </li>
               
                <li>
                    <a class="nav-link page-scroll" href="<?php echo base_url() ?>public/contact">contact</a>
                </li>
            </ul>
        </div>
    </nav>
  </div>
</header>