<div class="footer">
    <div class="copyright">
        <p class=""> © 2024 Copyright <a href="index.html"><strong>:: PAN SURYA ::</strong> </a>, Concepted By <a href="https:maasaradhi.com/">SARADHI CONSULTANCY PVT LTD</a>. All Rights Reserved. </p>
    </div>
</div>
<!--**********************************
    Footer end
***********************************-->        
		
	</div>
	
			<script src="<?php echo base_url() ?>assets/vendor/global/global.min.js"></script>
			<script src="<?php echo base_url() ?>assets/vendor/bootstrap-select/dist/js/bootstrap-select.min.js"></script>

			<script src="<?php echo base_url() ?>assets/vendor/sweetalert2/dist/sweetalert2.min.js"></script>
			<script src="<?php echo base_url() ?>assets/js/plugins-init/sweetalert.init.js"></script>

			<script src="<?php echo base_url() ?>assets/vendor/chart.js/Chart.bundle.min.js"></script>
			<script src="<?php echo base_url() ?>assets/vendor/peity/jquery.peity.min.js"></script>
			<script src="<?php echo base_url() ?>assets/vendor/apexchart/apexchart.js"></script>
			<script src="<?php echo base_url() ?>assets/vendor/owl-carousel/owl.carousel.js"></script>
			<script src="<?php echo base_url() ?>assets/js/dashboard/dashboard-1.js"></script>
		
			<script src="<?php echo base_url() ?>assets/js/custom.min.js"></script>
			<script src="<?php echo base_url() ?>assets/js/deznav-init.js"></script>
			<script src="<?php echo base_url() ?>assets/js/demo.js"></script>
			
			<!-- <link href="http://hayageek.github.io/jQuery-Upload-File/4.0.11/uploadfile.css" rel="stylesheet">	 -->
<!-- <script src="http://hayageek.github.io/jQuery-Upload-File/4.0.11/jquery.uploadfile.min.js"></script> -->
<!--			<script src="<?php echo base_url() ?>assets/js/styleSwitcher.js"></script>-->
			<script>
		function carouselReview(){
			/*  testimonial one function by = owl.carousel.js */
			/*  testimonial one function by = owl.carousel.js */
			jQuery('.testimonial-one').owlCarousel({
				loop:true,
				margin:10,
				nav:false,
				center:true,
				dots: false,
				navText: ['<i class="fas fa-caret-left"></i>', '<i class="fas fa-caret-right"></i>'],
				responsive:{
					0:{
						items:2
					},
					400:{
						items:3
					},	
					700:{
						items:5
					},	
					991:{
						items:6
					},			
					
					1200:{
						items:4
					},
					1600:{
						items:5
					}
				}
			})	
		}
		
		jQuery(window).on('load',function(){
			setTimeout(function(){
				carouselReview();
			}, 1000); 
		});
	</script>
    <!--**********************************
        Main wrapper end
    ***********************************-->
</body>
</html>