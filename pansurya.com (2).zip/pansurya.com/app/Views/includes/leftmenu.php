
<div class="deznav">
                <div class="deznav-scroll">
                    <ul class="metismenu" id="menu">
                        <li class="active">
                            <a href="<?php echo base_url() ?>public/dashboard"><i class="flaticon-381-app"></i>
								<span class="nav-text">Dashboard</span>
                            </a>
                        </li>
						<li class="mm-active">
                            <a href="<?php echo base_url() ?>public/services"><i class="flaticon-381-user-4"></i>
								<span class="nav-text">Service</span>
                            </a>
                        </li>
						
                        <li class="">
                            <a href="<?php echo base_url() ?>public/follower"><i class="flaticon-381-like"></i>
								<span class="nav-text">My followers</span>
                            </a>
                        </li>
						<li>
                            <a href="<?php echo base_url() ?>public/contact"><i class="flaticon-381-folder-11"></i>
								<span class="nav-text">contact</span>
                            </a>
                        </li>
                    </ul>
                  </div>
            </div>
<!--**********************************
    Sidebar end