<?php echo view('includes/header');?>
	      
<!--**********************************
    Header start
***********************************-->
<?php echo view('includes/top_right_menu');?>
<!--**********************************
    Header end ti-comment-alt
***********************************-->        <!--**********************************
    Sidebar start
***********************************-->
<?php echo view('includes/leftmenu');?>
<!--**********************************
    Sidebar end
***********************************-->        <!--**********************************
    Content body start
***********************************-->
<div class="content-body">
    <!-- row -->
	<div class="container-fluid">
		<div class="page-titles">
			<div class="row">
				<div class="col-auto col-lg-9 m-auto text-center">
					<ol class="breadcrumb pt-2">
						<li class="breadcrumb-item"><a href="javascript:void(0)">Dashboard</a></li>
						<li class="breadcrumb-item active"><a href="javascript:void(0)">Service</a></li>
					</ol>
				</div>
				<div class="col-lg-3">
					<div class="clearfix float-lg-end text-center">
<!--						<a href="javascript:void()" class="btn btn-primary light"><i class="fa fa-reply"></i> </a>-->
						
						<a href="<?php echo base_url()?>public/services/add" class="btn btn-primary light ms-2"><i class="fas fa-add px-2"></i>Add Service</a>
					</div>
				</div>
			</div>
        </div>
		
		<div class="row">

			<?php
			if($serv!== null){
			foreach($serv as $row) { ?>
			<div class="col-xl-4 col-sm-6">
				<div class="card">
					<div class="card-body p-2">
						<div class="new-arrival-product">
							<div class="new-arrivals-img-contnent">
								<img class="img-fluid" src="<?php echo base_url(); ?>assets/images/login-page.jpg" alt="">
							</div>
							
							<div class="new-arrival-content text-center mt-3 p-2">
								<hr>
								<h4><?php echo $row['pro_name']; ?></h4>
								<h6><?php echo $row['pro_date']; ?></h6>
								
								<hr>
								<div class="d-block text-center">
									<a href="<?php echo base_url(); ?>public/services/view/<?php echo $row['id']; ?>" class="btn btn-success btn-xs me-1 shadow sharp"><i class="fa-expand fas"></i></a>
									<a href="<?php echo base_url(); ?>public/services/edit/<?php echo $row['id']; ?>" class="btn btn-primary shadow btn-xs sharp me-1"><i class="fas fa-pencil-alt"></i></a>
								 <a href="#" class="btn btn-danger shadow btn-xs sharp  sweetalert "><i class="fas fa-trash-alt sweet-success-cancel"></i></a> 
									<!-- <div class="sweetalert mt-5">
                                <button class="btn btn-warning btn sweet-success-cancel">Sweet Confirm Or
                                    Cancel</button> -->
                            </div>

								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<?php }
			
		} else {
			echo "<tr><td colspan='4'></td></tr>";
		}
		?>
	</div>
    </div>
</div>
<?php echo view('includes/footer');?>