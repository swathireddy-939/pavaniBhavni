<?php echo view('includes/header');?>
    <!--*******************
        Preloader end
    ********************-->
	

<!--**********************************
    Nav header end
***********************************-->		      
<!--**********************************
    Header start
***********************************-->
<?php echo view('includes/top_right_menu');?>
<!--**********************************
    Header end ti-comment-alt
***********************************-->        <!--**********************************
    Sidebar start
***********************************-->
<?php echo view('includes/leftmenu');?>
<!--**********************************
    Sidebar end
***********************************-->        <!--**********************************
    Content body start
***********************************-->

<div class="content-body">
                <!-- row -->
         <div class="container-fluid">
		<div class="page-titles">
			<div class="row">
				<div class="col-auto col-lg-9 m-auto text-center">
					<ol class="breadcrumb pt-2">
						<li class="breadcrumb-item"><a href="javascript:void(0)">Dashboard</a></li>
						<li class="breadcrumb-item"><a href="javascript:void(0)">Service</a></li>
						<li class="breadcrumb-item active"><a href="javascript:void(0)">View Service</a></li>
					</ol>
				</div>
				<div class="col-lg-3">
					<div class="clearfix float-lg-end text-center">
						<!-- <a href="add_verified.html" class="btn btn-primary light"><i class="fa fa-reply"></i> </a>
						
						<a href="verified.html" class="btn btn-primary light ms-2"><i class="fas fa-save px-2"></i>Save</a> -->
					</div>
				</div>
			</div>
        </div>
		<!-- row -->
		<div class="row">
			<div class="row justify-content-center mt-5 pb-3">
        	<div class="col-xl-6 col-lg-7 col-md-9 text-center text-lg-start">
            	<div class="heading_s1">
                	<h2>Program Name</h2>
                </div>
            </div>
			
			<div class="col-xl-6 col-lg-7 col-md-9 text-center text-lg-end">
            	<div class="heading_s1">
                	<h2> <span>Date :</span><?php// echo $view['pro_date'];?>  </h2>
                </div>
            </div>
        </div>
		
			<div class="row ser_img">
			<?php 
			if ($serv!== null) {

				foreach($serv as $row) { ?>
				<div class="col-lg-2">
					<img src="<?php echo base_url();?>public/uploads/service/<?php echo $row['pro_image'];?>" alt="">
				</div>
				<?php } 
				  }else {
                                                echo "<tr><td colspan='4'></td></tr>";
                                            }?>
			</div>
			
		</div>
		
	</div>
            </div>		
		

<!--**********************************
    Content body end
***********************************-->
        <!--**********************************
    Footer start
***********************************-->
<?php echo view('includes/footer');?>