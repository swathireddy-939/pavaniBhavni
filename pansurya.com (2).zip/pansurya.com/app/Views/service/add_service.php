<?php echo view('includes/header');?>



<!--**********************************
    Nav header end
***********************************-->		      
<!--**********************************
    Header start
***********************************-->
<?php echo view('includes/top_right_menu');?>
<!--**********************************
    Header end ti-comment-alt
***********************************-->        <!--**********************************
    Sidebar start
***********************************-->
<?php echo view('includes/leftmenu');?>
<!--**********************************
    Sidebar end
***********************************-->        <!--**********************************
    Content body start
***********************************-->
		
<div class="content-body">
                <!-- row -->
         <div class="container-fluid">
		<div class="page-titles">
			<div class="row">
				<div class="col-auto col-lg-9 m-auto text-center">
					<ol class="breadcrumb pt-2">
						<li class="breadcrumb-item"><a href="javascript:void(0)">Dashboard</a></li>
						<li class="breadcrumb-item"><a href="javascript:void(0)">Service</a></li>
						<li class="breadcrumb-item active"><a href="javascript:void(0)">Add service </a></li>
					</ol>
				</div>
				<div class="col-lg-3">
					<div class="clearfix float-lg-end text-center">
<!--						<a href="javascript:void()" class="btn btn-primary light"><i class="fa fa-reply"></i> </a>-->
						
<!--						<a href="add_splashscreen.html" class="btn btn-primary light ms-2"><i class="fas fa-add px-2"></i>Add New Screen</a>-->
					</div>
				</div>
			</div>
        </div>
		<!-- row -->
		<div class="row">
			<div class="col-xl-12 col-lg-12">
                <div class="card">
                    
                    <div class="card-body">
                        <div class="basic-form">
							
		<form  method="post" id="service_form" name="service_form" enctype="multipart/form-data"  action="<?php echo base_url(); ?>public/services/add" >
										<input type="hidden" name="ser_id" id="ser_id" value="<?php echo $ser_id; ?>" hidden>
			                               <input type="hidden" name="action_type" id="action_type" value="<?php echo ($ser_id!=""?'edit':'add'); ?>">
			
           

              <div class="row">
				 
                  <hr class="dashed ">
                  <div class="col-sm-9">
                <div class="form-group mb-10">
                  <lable> Programmer Name</lable>
                  <input name="pro_name" id="pro_name" class="form-control" type="text" value="<?php echo (isset($record['pro_name']) ? $record['pro_name']: ""); ?>" placeholder="Programmer Name"  aria-required="true">
                </div>
              </div>
				  
				  <div class="col-sm-3">
                <div class="form-group mb-10">
                  <lable>Date</lable>
                  <input name="pro_date" id="pro_date" class="form-control" value="<?php echo (isset($record['pro_date']) ? $record['pro_date']: ""); ?>" type="date"  aria-required="true">
                </div>
              </div>
				  
				  <div class="mb-12">
										<label class="form-label">Upload Programmer Image</label>
										<div class="input-group mb-3">
											<div class="form-file">
											<input type="file" id="pro_image" name="pro_image[]"  multiple>
											</div>
											

											
										</div>
                                    </div>
									</div>
											<div class="float-end">
												<div class="form-actions">
													<div class="row">
														<div class="col-md-12">
														<button type="submit" class="btn btn-primary btn-rounded">Submit</button>
															<button class="btn btn-close-white btn-light btn-outline btn-rounded">Cancel</button>
														</div>
													</div>
												</div>
											</div>
			</form>
						
<!--
                                <div class="row">
									
									<div class="mb-3 col-md-4">
                                        <label class="form-label">Status</label>
                                        <select id="inputState" class="default-select form-control wide">
                                            <option selected="">Choose...</option>
                                            <option>Active</option>
                                            <option>De-Active</option>
                                        </select>
                                    </div>
									
									<a href="view_verified.html" type="submit" class="btn btn-primary">Submit</a>
									
                                </div>
-->
                                
                           
                        </div>
                    </div>
                </div>
			</div>
		</div>
				
	</div>
            </div>		
		

<!--**********************************
    Content body end
***********************************-->
        <!--**********************************
    Footer start
***********************************-->
<?php echo view('includes/footer');?>
