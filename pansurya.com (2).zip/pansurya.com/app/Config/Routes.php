<?php


namespace Config;

// Create a new instance of our RouteCollection class.
$routes = Services::routes();

/*
 * --------------------------------------------------------------------
 * Router Setup
 * --------------------------------------------------------------------
 */
$routes->setDefaultNamespace('App\Controllers');
$routes->setDefaultController('Login');
$routes->setDefaultMethod('index');
$routes->setTranslateURIDashes(false);
$routes->set404Override();
// The Auto Routing (Legacy) is very dangerous. It is easy to create vulnerable apps
// where controller filters or CSRF protection are bypassed.
// If you don't want to define all routes, please use the Auto Routing (Improved).
// Set `$autoRoutesImproved` to true in `app/Config/Feature.php` and set the following to true.
// $routes->setAutoRoute(false);

/*
 * --------------------------------------------------------------------
 * Route Definitions
 * --------------------------------------------------------------------
 */

// We get a performance increase by specifying the default
// route since we don't have to scan directories.
// $routes->get('/', 'Home::index');
$routes->get('/', 'Frontend::index');
$routes->get('follow', 'Frontend::follow');
$routes->get('service', 'Frontend::service');
$routes->get('contact', 'Frontend::contact');
$routes->match(['get', 'post'],'savefollow', 'Frontend::save');



$routes->get('dashboard', 'Dashboard::index');
$routes->get('services', 'Service::index');
$routes->match(['get', 'post'],'services/add', 'Service::add');

$routes->get('services/edit/(:num)','Service::add/$1');

$routes->get('services/view/(:num)','Service::view/$1');
$routes->match(['get', 'post'],'services/upload', 'Service::upload');

$routes->get('contact', 'Contact::index');
$routes->match(['get', 'post'],'contact/add', 'Contact::add');

$routes->get('follower', 'Follower::index');
$routes->match(['get', 'post'],'savefollow', 'Frontend::add');
$routes->get('follower/view/(:num)','Follower::view/$1');

$routes->get('admin', 'User::index');
$routes->match(['get', 'post'],'admin/logout','User::logout');
$routes->match(['get', 'post'],'login/auth','User::auth');
$routes->get('profile', 'User::profile');
$routes->get('profile', 'User::profile');
 $routes->get('forgot_pass', 'Request::forgot_pass');


/*
 * --------------------------------------------------------------------
 * Additional Routing
 * --------------------------------------------------------------------
 *
 * There will often be times that you need additional routing and you
 * need it to be able to override any defaults in this file. Environment
 * based routes is one such time. require() additional route files here
 * to make that happen.
 *
 * You will have access to the $routes object within that file without
 * needing to reload it.
 */
if (is_file(APPPATH . 'Config/' . ENVIRONMENT . '/Routes.php')) {
    require APPPATH . 'Config/' . ENVIRONMENT . '/Routes.php';
}

